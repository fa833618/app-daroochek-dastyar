const express = require('express');
const cors = require('cors');
const fs = require('fs');
const os = require('os');
const path = require('path');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const { randomUUID, randomBytes, scryptSync, timingSafeEqual } = require('crypto');

const PORT = process.env.PORT || 4000;
const HOST = process.env.HOST || '0.0.0.0';
const ADMIN_USERNAME = (process.env.ADMIN_USERNAME || 'admin').trim().toLowerCase();
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';
const JWT_SECRET = process.env.JWT_SECRET || 'change-me';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '1h';
const REFRESH_EXPIRES_DAYS = Number(process.env.REFRESH_EXPIRES_DAYS || 30);
const DATABASE_URL = process.env.DATABASE_URL;
const FARAZSMS_API_KEY = (process.env.FARAZSMS_API_KEY || '').trim();
const FARAZSMS_PATTERN_CODE = (process.env.FARAZSMS_PATTERN_CODE || '').toString().trim();
const FARAZSMS_SENDER_NUMBER = (process.env.FARAZSMS_SENDER_NUMBER || '').trim();
const FARAZSMS_CODE_PARAM = (process.env.FARAZSMS_CODE_PARAM || 'code').trim() || 'code';
const FARAZSMS_PURPOSE_PARAM = (process.env.FARAZSMS_PURPOSE_PARAM || '').trim();
const FARAZSMS_API_URL =
  process.env.FARAZSMS_API_URL ||
  'https://edge.ippanel.com/v1/api/send';
const codeApiEnabled =
  FARAZSMS_API_KEY &&
  FARAZSMS_PATTERN_CODE &&
  FARAZSMS_SENDER_NUMBER &&
  FARAZSMS_API_URL.startsWith('http');

const FCM_SERVER_KEY = (process.env.FCM_SERVER_KEY || '').trim();
const pushEnabled = Boolean(FCM_SERVER_KEY);

if (!DATABASE_URL) {
  throw new Error('DATABASE_URL is required to run the API.');
}

const pool = new Pool({
  connectionString: DATABASE_URL,
  ssl: process.env.PGSSLMODE === 'disable' ? false : { rejectUnauthorized: false },
});
const db = {
  query: (text, params) => pool.query(text, params),
};

const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

const app = express();
const corsOptions = {
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
};
app.use(cors(corsOptions));
app.options('*', cors(corsOptions));
// Allow larger JSON bodies for base64-encoded images
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
const DEFAULT_UPLOAD_ROOT = path.join(process.cwd(), 'uploads');
const ensureDir = (dir) => {
  try {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    return dir;
  } catch (err) {
    const fallback = path.join(os.tmpdir(), 'darocheck_uploads');
    if (!fs.existsSync(fallback)) {
      fs.mkdirSync(fallback, { recursive: true });
    }
    // eslint-disable-next-line no-console
    console.error(`Failed to create upload dir ${dir}, using fallback ${fallback}`, err);
    return fallback;
  }
};
const UPLOAD_ROOT = ensureDir(process.env.UPLOAD_DIR ? path.resolve(process.env.UPLOAD_DIR) : DEFAULT_UPLOAD_ROOT);
const AUDIO_DIR = ensureDir(path.join(UPLOAD_ROOT, 'audio'));
app.use('/uploads', express.static(UPLOAD_ROOT));

const makeTracking = () => randomBytes(3).toString('hex').toUpperCase();
const makeOtp = () => String(Math.floor(Math.random() * 10000)).padStart(4, '0');
const makeRefreshToken = () => randomBytes(48).toString('hex');
const makeLoginOtp = () => String(Math.floor(Math.random() * 10000)).padStart(4, '0');

const hashPassword = (password) => {
  const salt = randomBytes(16).toString('hex');
  const hash = scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
};

const verifyPassword = (password, stored) => {
  if (!stored || !stored.includes(':')) return false;
  const [salt, hex] = stored.split(':');
  const hash = scryptSync(password, salt, 64);
  return timingSafeEqual(Buffer.from(hex, 'hex'), hash);
};

const serializeUserRow = (row) => ({
  id: row.id,
  username: row.username,
  firstName: row.first_name || '',
  lastName: row.last_name || '',
  phone: row.phone || '',
  phoneVerified: Boolean(row.phone_verified),
  role: row.role || 'user',
  createdAt: row.created_at ? new Date(row.created_at).toISOString() : new Date().toISOString(),
});
const serializeUser = (user) => serializeUserRow(user);
const ORDER_STATUSES = ['در حال بررسی', 'یافت شد', 'ارسال شد', 'تکمیل', 'لغو'];
const ORDER_CATEGORIES = ['دارو', 'مکمل', 'تجهیزات', 'لوازم مصرفی', 'درخواست ویژه'];
const USER_ROLES = ['user', 'admin', 'colleague', 'reception'];

let ordersColumns = null;
const loadOrdersColumns = async () => {
  try {
    const { rows } = await db.query(
      `SELECT column_name
       FROM information_schema.columns
       WHERE table_schema = 'public' AND table_name = 'orders'`,
    );
    ordersColumns = new Set(rows.map((r) => r.column_name));
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to load orders columns', err);
    ordersColumns = null;
  }
};

const ensureOrdersSchema = async () => {
  try {
    const { rows } = await db.query(`SELECT to_regclass('public.orders') AS reg`);
    if (!rows[0]?.reg) return;

    await db.query(`ALTER TABLE orders ADD COLUMN IF NOT EXISTS category TEXT NOT NULL DEFAULT 'دارو'`);
    await db.query(`ALTER TABLE orders ADD COLUMN IF NOT EXISTS customer_name TEXT NOT NULL DEFAULT ''`);
    await db.query(`ALTER TABLE orders ADD COLUMN IF NOT EXISTS notes TEXT NOT NULL DEFAULT ''`);
    await db.query(`ALTER TABLE orders ADD COLUMN IF NOT EXISTS image_url TEXT NOT NULL DEFAULT ''`);
    await db.query(`ALTER TABLE orders ADD COLUMN IF NOT EXISTS audio_url TEXT NOT NULL DEFAULT ''`);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Orders schema migration failed', err);
  } finally {
    await loadOrdersColumns();
  }
};

const ensureSchema = async () => {
  await ensureOrdersSchema();
  await ensureNotificationsSchema();
  await ensurePushTokensSchema();
};

const ensureNotificationsSchema = async () => {
  try {
    await db.query(
      `CREATE TABLE IF NOT EXISTS notifications (
        id UUID PRIMARY KEY,
        user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        type TEXT NOT NULL,
        title TEXT NOT NULL DEFAULT '',
        body TEXT NOT NULL DEFAULT '',
        data JSONB NOT NULL DEFAULT '{}'::jsonb,
        is_read BOOLEAN NOT NULL DEFAULT FALSE,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )`,
    );
    await db.query(
      `CREATE INDEX IF NOT EXISTS idx_notifications_user_unread_created
       ON notifications(user_id, is_read, created_at DESC)`,
    );
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Notifications schema migration failed', err);
  }
};

const ensurePushTokensSchema = async () => {
  try {
    await db.query(
      `CREATE TABLE IF NOT EXISTS user_push_tokens (
        id UUID PRIMARY KEY,
        user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        token TEXT NOT NULL UNIQUE,
        platform TEXT NOT NULL DEFAULT '',
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )`,
    );
    await db.query(
      `CREATE INDEX IF NOT EXISTS idx_user_push_tokens_user
       ON user_push_tokens(user_id, updated_at DESC)`,
    );
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Push tokens schema migration failed', err);
  }
};

const createNotification = async ({ userId, type, title, body, data }) => {
  const id = randomUUID();
  const payload = data ? JSON.stringify(data) : '{}';
  await db.query(
    `INSERT INTO notifications (id, user_id, type, title, body, data, is_read, created_at)
     VALUES ($1,$2,$3,$4,$5,$6,false,NOW())`,
    [id, userId, type, title || '', body || '', payload],
  );
  return id;
};

const fetchPushTokens = async (userId) => {
  const { rows } = await db.query('SELECT token FROM user_push_tokens WHERE user_id = $1', [userId]);
  return rows.map((r) => r.token).filter(Boolean);
};

const getUnreadNotificationsCount = async (userId) => {
  const { rows } = await db.query(
    "SELECT COUNT(*)::int AS count FROM notifications WHERE user_id = $1 AND is_read = false AND type <> 'chat_message'",
    [userId],
  );
  return rows[0]?.count || 0;
};

const getUnreadOrderNotificationsCount = async (userId) => {
  const orderTypes = ['order_created', 'order_status', 'special_request_created'];
  const { rows } = await db.query(
    'SELECT COUNT(*)::int AS count FROM notifications WHERE user_id = $1 AND is_read = false AND type = ANY($2::text[])',
    [userId, orderTypes],
  );
  return rows[0]?.count || 0;
};

const getUnreadChatCountByUserId = async (userId) => {
  const { rows: userRows } = await db.query('SELECT role FROM users WHERE id = $1', [userId]);
  if (userRows.length === 0) return 0;
  const role = userRows[0].role;
  if (role === 'admin') {
    const { rows } = await db.query(
      `SELECT COUNT(*)::int AS count
       FROM chat_messages m
       JOIN chat_threads t ON t.id = m.thread_id
       JOIN users u ON u.id = t.client_id
       WHERE u.role = 'colleague' AND m.sender_role = 'client' AND m.is_read = false`,
    );
    return rows[0]?.count || 0;
  }
  if (role === 'colleague') {
    const { rows } = await db.query(
      `SELECT COUNT(*)::int AS count
       FROM chat_messages m
       JOIN chat_threads t ON t.id = m.thread_id
       WHERE t.client_id = $1 AND m.sender_role = 'admin' AND m.is_read = false`,
      [userId],
    );
    return rows[0]?.count || 0;
  }
  return 0;
};

const sendPush = async ({ tokens, title, body, data, badge }) => {
  if (!pushEnabled) return { sent: false, reason: 'disabled' };
  if (!tokens || tokens.length === 0) return { sent: false, reason: 'no_tokens' };
  try {
    const payload = {
      registration_ids: tokens,
      priority: 'high',
      notification: {
        title: title || '',
        body: body || '',
        sound: 'default',
        android_channel_id: 'darocheck_default',
        ...(Number.isFinite(Number(badge)) ? { badge: Number(badge) } : {}),
      },
      data: {
        ...(data || {}),
        click_action: 'FLUTTER_NOTIFICATION_CLICK',
      },
    };
    const resp = await fetch('https://fcm.googleapis.com/fcm/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `key=${FCM_SERVER_KEY}`,
      },
      body: JSON.stringify(payload),
    });
    const text = await resp.text();
    if (!resp.ok) {
      throw new Error(text || `status ${resp.status}`);
    }
    return { sent: true, response: text };
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to send push', err.message);
    return { sent: false, error: err.message };
  }
};

const notifyUsers = async ({ userIds, type, title, body, data }) => {
  const uniqueUserIds = [...new Set((userIds || []).filter(Boolean))];
  for (const userId of uniqueUserIds) {
    if (type !== 'chat_message') {
      await createNotification({ userId, type, title, body, data });
    }
    const [unreadNotifs, unreadChats, tokens] = await Promise.all([
      getUnreadNotificationsCount(userId),
      getUnreadChatCountByUserId(userId),
      fetchPushTokens(userId),
    ]);
    await sendPush({
      tokens,
      title,
      body,
      data,
      badge: unreadNotifs + unreadChats,
    });
  }
};

const signToken = (user) =>
  jwt.sign(
    {
      sub: user.id,
      role: user.role || 'user',
      username: user.username,
    },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN },
  );

const getUserFromRequest = async (req) => {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.replace('Bearer ', '').trim() : '';
  if (!token) return null;
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const { rows } = await db.query('SELECT * FROM users WHERE id = $1', [payload.sub]);
    return rows[0] ? serializeUserRow(rows[0]) : null;
  } catch (_err) {
    return null;
  }
};

let refreshTokens = [];
const issueRefreshToken = (userId) => {
  const token = makeRefreshToken();
  const expiresAt = Date.now() + REFRESH_EXPIRES_DAYS * 24 * 60 * 60 * 1000;
  refreshTokens = refreshTokens.filter((t) => t.userId !== userId);
  refreshTokens.push({ token, userId, expiresAt });
  return { token, expiresAt };
};

const verifyRefreshToken = (token) => {
  if (!token) return null;
  const record = refreshTokens.find((t) => t.token === token);
  if (!record) return null;
  if (record.expiresAt < Date.now()) {
    refreshTokens = refreshTokens.filter((t) => t.token !== token);
    return null;
  }
  return record;
};

const revokeRefreshToken = (token) => {
  refreshTokens = refreshTokens.filter((t) => t.token !== token);
};

const saveBase64Audio = (audioBase64) => {
  if (!audioBase64) return '';
  const cleaned = audioBase64.includes(',') ? audioBase64.split(',').pop() : audioBase64;
  const buffer = Buffer.from(cleaned, 'base64');
  const fileName = `${randomUUID()}.m4a`;
  const filePath = path.join(AUDIO_DIR, fileName);
  fs.writeFileSync(filePath, buffer);
  return `/uploads/audio/${fileName}`;
};

const serializeThreadRow = (row) => ({
  id: row.id,
  clientId: row.client_id,
  adminId: row.admin_id,
  clientFirstName: row.client_first_name || null,
  clientLastName: row.client_last_name || null,
  status: row.status,
  unreadCount: Number(row.unread_count || 0),
  createdAt: row.created_at ? new Date(row.created_at).toISOString() : null,
  updatedAt: row.updated_at ? new Date(row.updated_at).toISOString() : null,
  lastMessage: row.last_message
    ? {
        body: row.last_message,
        createdAt: row.last_message_created_at ? new Date(row.last_message_created_at).toISOString() : null,
      }
    : null,
});

const serializeMessageRow = (row) => ({
  id: row.id,
  threadId: row.thread_id,
  senderId: row.sender_id,
  senderRole: row.sender_role,
  body: row.body,
  attachmentUrl: row.attachment_url || '',
  isRead: Boolean(row.is_read),
  createdAt: row.created_at ? new Date(row.created_at).toISOString() : null,
});

const dispatchCode = async ({ phone, code, purpose }) => {
  if (!codeApiEnabled) {
    return { sent: false, devCode: code };
  }
  try {
    const params = { [FARAZSMS_CODE_PARAM]: code };
    if (FARAZSMS_PURPOSE_PARAM && purpose) {
      params[FARAZSMS_PURPOSE_PARAM] = purpose;
    }

    const resp = await fetch(FARAZSMS_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: FARAZSMS_API_KEY,
      },
      body: JSON.stringify({
        sending_type: 'pattern',
        from_number: FARAZSMS_SENDER_NUMBER,
        code: FARAZSMS_PATTERN_CODE,
        recipients: [phone],
        params,
      }),
    });
    const text = await resp.text();
    let data = null;
    try {
      data = JSON.parse(text);
    } catch (_err) {
      data = null;
    }
    const success = resp.ok && data?.meta?.status;
    if (!success) {
      const errorMessage = data?.meta?.message || text || `status ${resp.status}`;
      throw new Error(errorMessage);
    }
    return { sent: true };
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to send verification code', err.message);
    return { sent: false, error: err.message, devCode: code };
  }
};

const ensureAdminUser = async () => {
  const { rows } = await db.query('SELECT * FROM users WHERE username = $1', [ADMIN_USERNAME]);
  if (rows.length === 0) {
    const passwordHash = hashPassword(ADMIN_PASSWORD);
    const insert =
      'INSERT INTO users (id, username, first_name, last_name, phone, password_hash, phone_verified, role) VALUES ($1,$2,$3,$4,$5,$6,true,$7)';
    await db.query(insert, [
      randomUUID(),
      ADMIN_USERNAME,
      'Admin',
      'User',
      ADMIN_USERNAME,
      passwordHash,
      'admin',
    ]);
  } else {
    const passwordHash = hashPassword(ADMIN_PASSWORD);
    await db.query(
      'UPDATE users SET role=$2, phone=$3, password_hash=$4, phone_verified=true WHERE username=$1',
      [ADMIN_USERNAME, 'admin', ADMIN_USERNAME, passwordHash],
    );
  }
};

const requireAdmin = async (req, res, next) => {
  try {
    const user = await getUserFromRequest(req);
    if (!user) return res.status(401).json({ message: 'Unauthorized' });
    if (user.role !== 'admin') return res.status(403).json({ message: 'Admin only' });
    req.user = user;
    return next();
  } catch (err) {
    return next(err);
  }
};

app.get('/api/partner/profile', asyncHandler(async (req, res) => {
  const user = await getUserFromRequest(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  const { rows } = await db.query(
    `SELECT id, user_id, business_name, business_type, license_number, city, address,
            contact_name, review_status, created_at, updated_at
     FROM colleague_profiles WHERE user_id = $1`,
    [user.id],
  );
  return res.json({ data: rows[0] || null });
}));

app.post('/api/partner/profile', asyncHandler(async (req, res) => {
  const user = await getUserFromRequest(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  if (!['colleague', 'reception'].includes(user.role)) return res.status(403).json({ message: 'Partner account required.' });
  const { businessName, businessType = 'pharmacy', licenseNumber = '', city = '', address = '', contactName = '' } = req.body || {};
  if (typeof businessName !== 'string' || !businessName.trim()) {
    return res.status(400).json({ message: 'Business name is required.' });
  }
  const { rows } = await db.query(
    `INSERT INTO colleague_profiles
      (id, user_id, business_name, business_type, license_number, city, address, contact_name, review_status, created_at, updated_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'pending',NOW(),NOW())
     ON CONFLICT (user_id) DO UPDATE SET business_name=EXCLUDED.business_name,
       business_type=EXCLUDED.business_type, license_number=EXCLUDED.license_number,
       city=EXCLUDED.city, address=EXCLUDED.address, contact_name=EXCLUDED.contact_name,
       updated_at=NOW()
     RETURNING *`,
    [randomUUID(), user.id, businessName.trim(), String(businessType).trim(), String(licenseNumber).trim(),
      String(city).trim(), String(address).trim(), String(contactName).trim()],
  );
  return res.status(201).json({ data: rows[0] });
}));

app.get('/api/membership/plans', asyncHandler(async (_req, res) => {
  const { rows } = await db.query(
    `SELECT id, code, name, description, price_amount, currency, duration_days
     FROM membership_plans WHERE is_active = true ORDER BY price_amount ASC, created_at ASC`,
  );
  return res.json({ data: rows });
}));

app.post('/api/memberships', asyncHandler(async (req, res) => {
  const user = await getUserFromRequest(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  if (!['colleague', 'reception'].includes(user.role)) return res.status(403).json({ message: 'Partner account required.' });
  const { planId, paymentProvider = '' } = req.body || {};
  if (typeof planId !== 'string' || !planId.trim()) return res.status(400).json({ message: 'Plan is required.' });
  const { rows: plans } = await db.query('SELECT id FROM membership_plans WHERE id=$1 AND is_active=true', [planId]);
  if (!plans.length) return res.status(404).json({ message: 'Membership plan not found.' });
  const { rows } = await db.query(
    `INSERT INTO memberships (id, user_id, plan_id, status, payment_provider, created_at, updated_at)
     VALUES ($1,$2,$3,'pending',$4,NOW(),NOW()) RETURNING *`,
    [randomUUID(), user.id, planId, String(paymentProvider).trim()],
  );
  return res.status(201).json({ data: rows[0], nextStep: 'payment_provider_required' });
}));

app.get('/api/ads', asyncHandler(async (req, res) => {
  const slot = typeof req.query.slot === 'string' ? req.query.slot.trim() : '';
  const params = [];
  const where = ["a.status = 'running'", '(a.starts_at IS NULL OR a.starts_at <= NOW())', '(a.ends_at IS NULL OR a.ends_at >= NOW())'];
  if (slot) { params.push(slot); where.push(`s.code = $${params.length}`); }
  const { rows } = await db.query(
    `SELECT a.id, a.title, a.body, a.image_url, a.target_url, s.code AS slot_code,
            s.placement, s.size_label
     FROM advertisements a JOIN ad_slots s ON s.id = a.slot_id
     WHERE ${where.join(' AND ')} ORDER BY a.created_at DESC LIMIT 20`,
    params,
  );
  return res.json({ data: rows });
}));

app.post('/api/auth/register', asyncHandler(async (req, res) => {
  const { firstName, lastName, password, phone, role } = req.body || {};
  if (![firstName, lastName, password, phone].every((f) => typeof f === 'string' && f.trim())) {
    return res.status(400).json({ message: 'All fields are required.' });
  }
  const cleanPhone = phone.trim();
  const cleanUsername = cleanPhone.toLowerCase();
  const passwordHash = hashPassword(password);
  const desiredRole =
    typeof role === 'string' && USER_ROLES.includes(role.trim()) ? role.trim() : 'user';
  if (desiredRole === 'admin') {
    return res.status(403).json({ message: 'Cannot self-register as admin.' });
  }

  try {
    const insertUser = `
      INSERT INTO users (id, username, first_name, last_name, phone, password_hash, phone_verified, role)
      VALUES ($1,$2,$3,$4,$5,$6,false,$7)
      RETURNING *`;
    const { rows } = await db.query(insertUser, [
      randomUUID(),
      cleanUsername,
      firstName.trim(),
      lastName.trim(),
      cleanPhone,
      passwordHash,
      desiredRole,
    ]);
    const user = serializeUserRow(rows[0]);
    const code = makeOtp();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000);
    await db.query(
      `INSERT INTO phone_verification_codes (user_id, code, expires_at)
       VALUES ($1,$2,$3)
       ON CONFLICT (user_id) DO UPDATE SET code=EXCLUDED.code, expires_at=EXCLUDED.expires_at, created_at=NOW()`,
      [user.id, code, expiresAt],
    );
    const sendResult = await dispatchCode({ phone: cleanPhone, code, purpose: 'signup' });
    if (codeApiEnabled && !sendResult.sent) return res.status(502).json({ message: 'Failed to send verification code.' });
    return res.status(201).json({
      pendingVerification: true,
      username: cleanUsername,
      code: sendResult.devCode,
      expiresAt,
    });
  } catch (err) {
    if (err.code === '23505') {
      return res.status(409).json({ message: 'Phone already registered.' });
    }
    // eslint-disable-next-line no-console
    console.error('Register error', err);
    return res.status(500).json({ message: 'Registration failed.' });
  }
}));

app.post('/api/auth/verify', asyncHandler(async (req, res) => {
  const { username, code } = req.body || {};
  if (typeof username !== 'string' || typeof code !== 'string') {
    return res.status(400).json({ message: 'Username and code are required.' });
  }
  const cleanUsername = username.trim().toLowerCase();
  const { rows: userRows } = await db.query('SELECT * FROM users WHERE username = $1', [cleanUsername]);
  if (userRows.length === 0) return res.status(404).json({ message: 'User not found.' });
  const user = userRows[0];
  const { rows: codeRows } = await db.query(
    'SELECT code, expires_at FROM phone_verification_codes WHERE user_id = $1',
    [user.id],
  );
  if (codeRows.length === 0) return res.status(400).json({ message: 'No pending code.' });
  const record = codeRows[0];
  if (record.code !== code.trim()) return res.status(400).json({ message: 'Invalid code.' });
  if (Date.now() > new Date(record.expires_at).getTime()) return res.status(400).json({ message: 'Code expired.' });
  await db.query('UPDATE users SET phone_verified=true WHERE id=$1', [user.id]);
  await db.query('DELETE FROM phone_verification_codes WHERE user_id=$1', [user.id]);
  const refresh = issueRefreshToken(user.id);
  const token = signToken(serializeUserRow({ ...user, phone_verified: true }));
  return res.json({
    user: serializeUserRow({ ...user, phone_verified: true }),
    token,
    refreshToken: refresh.token,
    refreshExpiresAt: refresh.expiresAt,
  });
}));

app.post('/api/auth/login', asyncHandler(async (req, res) => {
  const { username, phone, password } = req.body || {};
  if (typeof password !== 'string') {
    return res.status(400).json({ message: 'Password is required.' });
  }
  const cleanUsername = typeof username === 'string' ? username.trim().toLowerCase() : '';
  const cleanPhone = typeof phone === 'string' ? phone.trim() : '';

  // Admin short-circuit
  if (cleanUsername === ADMIN_USERNAME || cleanPhone === ADMIN_USERNAME) {
    await ensureAdminUser();
    const { rows } = await db.query('SELECT * FROM users WHERE username=$1', [ADMIN_USERNAME]);
    const admin = serializeUserRow(rows[0]);
    if (password !== ADMIN_PASSWORD) {
      return res.status(401).json({ message: 'Invalid credentials.' });
    }
    const refresh = issueRefreshToken(admin.id);
    const token = signToken(admin);
    return res.json({ user: serializeUser(admin), token, refreshToken: refresh.token, refreshExpiresAt: refresh.expiresAt });
  }

  const { rows } = await db.query('SELECT * FROM users WHERE phone=$1 OR username=$2', [
    cleanPhone,
    cleanUsername,
  ]);
  if (rows.length === 0) return res.status(404).json({ message: 'User not found.' });
  const user = rows[0];
  if (!verifyPassword(password, user.password_hash)) {
    return res.status(401).json({ message: 'Invalid credentials.' });
  }
  if (!user.phone_verified) {
    return res.status(403).json({ message: 'Phone not verified.' });
  }
  const refresh = issueRefreshToken(user.id);
  const token = signToken(serializeUserRow(user));
  return res.json({
    user: serializeUserRow(user),
    token,
    refreshToken: refresh.token,
    refreshExpiresAt: refresh.expiresAt,
  });
}));

// Request a one-time code for phone-based login.
app.post('/api/auth/login-code', asyncHandler(async (req, res) => {
  const { phone } = req.body || {};
  if (typeof phone !== 'string' || !phone.trim()) {
    return res.status(400).json({ message: 'Phone is required.' });
  }
  const cleanPhone = phone.trim();
  const { rows } = await db.query('SELECT * FROM users WHERE phone=$1', [cleanPhone]);
  if (rows.length === 0) return res.status(404).json({ message: 'User not found.' });
  const user = rows[0];
  if (!user.phone_verified) return res.status(403).json({ message: 'Phone not verified.' });
  const code = makeLoginOtp();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000);
  await db.query(
    `INSERT INTO phone_verification_codes (user_id, code, expires_at)
     VALUES ($1,$2,$3)
     ON CONFLICT (user_id) DO UPDATE SET code=EXCLUDED.code, expires_at=EXCLUDED.expires_at, created_at=NOW()`,
    [user.id, code, expiresAt],
  );
  const sendResult = await dispatchCode({ phone: cleanPhone, code, purpose: 'login' });
  if (codeApiEnabled && !sendResult.sent) {
    return res.status(502).json({ message: 'Failed to send code.' });
  }
  return res.json({ sent: true, code: sendResult.devCode, expiresAt });
}));

// Verify phone login code and issue tokens.
app.post('/api/auth/login-with-code', asyncHandler(async (req, res) => {
  const { phone, code } = req.body || {};
  if (![phone, code].every((v) => typeof v === 'string' && v.trim())) {
    return res.status(400).json({ message: 'Phone and code are required.' });
  }
  const cleanPhone = phone.trim();
  const { rows: userRows } = await db.query('SELECT * FROM users WHERE phone=$1', [cleanPhone]);
  if (userRows.length === 0) return res.status(404).json({ message: 'User not found.' });
  const user = userRows[0];
  const { rows: codeRows } = await db.query(
    'SELECT code, expires_at FROM phone_verification_codes WHERE user_id=$1',
    [user.id],
  );
  if (codeRows.length === 0) return res.status(400).json({ message: 'No pending code.' });
  const record = codeRows[0];
  if (record.code !== code.trim()) return res.status(400).json({ message: 'Invalid code.' });
  if (Date.now() > new Date(record.expires_at).getTime()) return res.status(400).json({ message: 'Code expired.' });
  await db.query('DELETE FROM phone_verification_codes WHERE user_id=$1', [user.id]);
  const refresh = issueRefreshToken(user.id);
  const token = signToken(serializeUserRow(user));
  return res.json({
    user: serializeUserRow(user),
    token,
    refreshToken: refresh.token,
    refreshExpiresAt: refresh.expiresAt,
  });
}));

app.post('/api/auth/refresh', asyncHandler(async (req, res) => {
  const { refreshToken } = req.body || {};
  if (typeof refreshToken !== 'string' || !refreshToken.trim()) {
    return res.status(400).json({ message: 'Refresh token required.' });
  }
  const record = verifyRefreshToken(refreshToken.trim());
  if (!record) return res.status(401).json({ message: 'Invalid refresh token.' });
  const { rows } = await db.query('SELECT * FROM users WHERE id=$1', [record.userId]);
  if (rows.length === 0) return res.status(401).json({ message: 'Invalid refresh token.' });
  const user = serializeUserRow(rows[0]);

  // rotate refresh token
  revokeRefreshToken(refreshToken.trim());
  const newRefresh = issueRefreshToken(user.id);
  const token = signToken(user);
  return res.json({
    token,
    refreshToken: newRefresh.token,
    refreshExpiresAt: newRefresh.expiresAt,
    user: serializeUser(user),
  });
}));

app.post('/api/auth/logout', (req, res) => {
  const { refreshToken } = req.body || {};
  if (typeof refreshToken === 'string') {
    revokeRefreshToken(refreshToken.trim());
  }
  return res.json({ ok: true });
});

app.post('/api/push/register', asyncHandler(async (req, res) => {
  const user = await getUserFromRequest(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  const { token, platform = '' } = req.body || {};
  if (typeof token !== 'string' || !token.trim()) {
    return res.status(400).json({ message: 'Push token is required.' });
  }
  const cleanToken = token.trim();
  const cleanPlatform = typeof platform === 'string' ? platform.trim().toLowerCase() : '';
  const id = randomUUID();
  await db.query(
    `INSERT INTO user_push_tokens (id, user_id, token, platform, created_at, updated_at)
     VALUES ($1,$2,$3,$4,NOW(),NOW())
     ON CONFLICT (token) DO UPDATE SET user_id=EXCLUDED.user_id, platform=EXCLUDED.platform, updated_at=NOW()`,
    [id, user.id, cleanToken, cleanPlatform],
  );
  return res.json({ ok: true, pushEnabled });
}));

app.post('/api/push/unregister', asyncHandler(async (req, res) => {
  const user = await getUserFromRequest(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  const { token } = req.body || {};
  if (typeof token !== 'string' || !token.trim()) {
    return res.status(400).json({ message: 'Push token is required.' });
  }
  await db.query('DELETE FROM user_push_tokens WHERE user_id = $1 AND token = $2', [user.id, token.trim()]);
  return res.json({ ok: true });
}));

app.get('/api/notifications/unread-count', asyncHandler(async (req, res) => {
  const user = await getUserFromRequest(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  const count = await getUnreadNotificationsCount(user.id);
  return res.json({ count });
}));

app.get('/api/notifications', asyncHandler(async (req, res) => {
  const user = await getUserFromRequest(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  const unreadOnly = String(req.query.unreadOnly || '').toLowerCase() === 'true';
  const limit = Math.max(1, Math.min(100, Number(req.query.limit || 30)));
  const params = [user.id];
  let sql = `SELECT id, type, title, body, data, is_read, created_at FROM notifications WHERE user_id = $1 AND type <> 'chat_message'`;
  if (unreadOnly) {
    sql += ' AND is_read = false';
  }
  sql += ' ORDER BY created_at DESC';
  sql += ` LIMIT $2`;
  params.push(limit);
  const { rows } = await db.query(sql, params);
  return res.json({
    data: rows.map((r) => ({
      id: r.id,
      type: r.type,
      title: r.title || '',
      body: r.body || '',
      data: r.data || {},
      isRead: Boolean(r.is_read),
      createdAt: r.created_at ? new Date(r.created_at).toISOString() : null,
    })),
  });
}));

app.post('/api/notifications/mark-read', asyncHandler(async (req, res) => {
  const user = await getUserFromRequest(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  const { ids, all = false, types } = req.body || {};
  if (all === true) {
    await db.query('UPDATE notifications SET is_read=true WHERE user_id=$1 AND is_read=false', [user.id]);
    return res.json({ ok: true });
  }
  if (Array.isArray(types) && types.length > 0) {
    const cleanTypes = types.filter((x) => typeof x === 'string' && x.trim());
    if (cleanTypes.length === 0) return res.status(400).json({ message: 'types is required.' });
    await db.query(
      'UPDATE notifications SET is_read=true WHERE user_id=$1 AND is_read=false AND type = ANY($2::text[])',
      [user.id, cleanTypes],
    );
    return res.json({ ok: true });
  }
  if (!Array.isArray(ids) || ids.length === 0) {
    return res.status(400).json({ message: 'ids is required.' });
  }
  const cleanIds = ids.filter((x) => typeof x === 'string' && x.trim());
  if (cleanIds.length === 0) return res.status(400).json({ message: 'ids is required.' });
  await db.query(
    'UPDATE notifications SET is_read=true WHERE user_id=$1 AND id = ANY($2::uuid[])',
    [user.id, cleanIds],
  );
  return res.json({ ok: true });
}));

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok' });
});

app.get('/api/drugs', asyncHandler(async (req, res) => {
  const query = (req.query.q || '').toString().trim().toLowerCase();
  const params = [];
  let sql = 'SELECT id, name, description, stock, created_at FROM drugs';
  if (query.length > 0) {
    params.push(`%${query}%`);
    sql += ` WHERE LOWER(name) LIKE $1`;
  }
  sql += ' ORDER BY created_at DESC';
  const { rows } = await db.query(sql, params);
  res.json({ data: rows.map((r) => ({ ...r, description: r.description || '' })) });
}));

app.post('/api/drugs', requireAdmin, asyncHandler(async (req, res) => {
  const { name, description = '', stock = 0 } = req.body || {};
  if (!name || typeof name !== 'string') {
    return res.status(400).json({ message: 'نام دارو الزامی است.' });
  }
  const drug = {
    id: randomUUID(),
    name: name.trim(),
    description: description ? description.toString().trim() : '',
    stock: Number.isFinite(Number(stock)) ? Number(stock) : 0,
  };
  await db.query(
    'INSERT INTO drugs (id, name, description, stock) VALUES ($1,$2,$3,$4)',
    [drug.id, drug.name, drug.description, drug.stock],
  );
  return res.status(201).json({ data: drug });
}));

app.get('/api/orders', asyncHandler(async (req, res) => {
  const user = await getUserFromRequest(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  const isAdmin = user.role === 'admin';
  const { drugName = '', tracking = '', status = '', date = '', startDate = '', endDate = '' } = req.query || {};

  const params = [];
  const where = [];

  if (!isAdmin) {
    params.push(user.id);
    where.push(`o.user_id = $${params.length}`);
  }

  if (drugName) {
    params.push(`%${drugName.toString().toLowerCase()}%`);
    where.push(`LOWER(o.drug_name) LIKE $${params.length}`);
  }

  if (tracking) {
    params.push(`%${tracking.toString().toLowerCase()}%`);
    where.push(`LOWER(o.tracking_code) LIKE $${params.length}`);
  }

  if (status && ORDER_STATUSES.includes(status.toString())) {
    params.push(status.toString());
    where.push(`o.status = $${params.length}`);
  }

  if (startDate) {
    params.push(startDate.toString());
    where.push(`DATE(o.created_at) >= $${params.length}`);
  }

  if (endDate) {
    params.push(endDate.toString());
    where.push(`DATE(o.created_at) <= $${params.length}`);
  }

  if (date) {
    params.push(date.toString());
    where.push(`DATE(o.created_at) = $${params.length}`);
  }

  if (!ordersColumns) {
    await ensureOrdersSchema();
  }
  const categorySelect = ordersColumns?.has('category') ? 'o.category' : `'دارو'::text AS category`;
  const customerNameSelect = isAdmin
    ? `TRIM(CONCAT_WS(' ', u.first_name, u.last_name)) AS "customerName"`
    : (ordersColumns?.has('customer_name')
      ? 'o.customer_name AS "customerName"'
      : `''::text AS "customerName"`);
  const notesSelect = ordersColumns?.has('notes') ? 'o.notes' : `''::text AS notes`;
  const imageUrlSelect = ordersColumns?.has('image_url') ? 'o.image_url AS "imageUrl"' : `''::text AS "imageUrl"`;
  const audioUrlSelect = ordersColumns?.has('audio_url') ? 'o.audio_url AS "audioUrl"' : `''::text AS "audioUrl"`;

  let sql = `
    SELECT o.id,
           o.tracking_code AS "trackingCode",
           o.drug_id AS "drugId",
           o.drug_name AS "drugName",
           o.quantity,
           o.user_id AS "userId",
           o.status,
           ${categorySelect},
           ${customerNameSelect},
           ${notesSelect},
           ${imageUrlSelect},
           ${audioUrlSelect},
           o.created_at AS "createdAt"
    FROM orders o
    ${isAdmin ? 'LEFT JOIN users u ON u.id = o.user_id' : ''}
  `;
  if (where.length > 0) {
    sql += ` WHERE ${where.join(' AND ')}`;
  }
  sql += ' ORDER BY o.created_at DESC';
  const { rows } = await db.query(sql, params);
  res.json({ data: rows });
}));

const csvEscape = (val) => {
  if (val === null || val === undefined) return '';
  const str = String(val).replace(/\"/g, '\"\"');
  return `"${str}"`;
};

app.get('/api/orders/export', requireAdmin, asyncHandler(async (req, res) => {
  const { drugName = '', tracking = '', status = '', date = '', startDate = '', endDate = '' } = req.query || {};
  const params = [];
  const where = [];

  if (drugName) {
    params.push(`%${drugName.toString().toLowerCase()}%`);
    where.push(`LOWER(drug_name) LIKE $${params.length}`);
  }

  if (tracking) {
    params.push(`%${tracking.toString().toLowerCase()}%`);
    where.push(`LOWER(tracking_code) LIKE $${params.length}`);
  }

  if (status && ORDER_STATUSES.includes(status.toString())) {
    params.push(status.toString());
    where.push(`status = $${params.length}`);
  }

  if (startDate) {
    params.push(startDate.toString());
    where.push(`DATE(created_at) >= $${params.length}`);
  }

  if (endDate) {
    params.push(endDate.toString());
    where.push(`DATE(created_at) <= $${params.length}`);
  }

  if (date) {
    params.push(date.toString());
    where.push(`DATE(created_at) = $${params.length}`);
  }

  if (!ordersColumns) {
    await ensureOrdersSchema();
  }
  const categorySelect = ordersColumns?.has('category') ? 'category' : `'دارو'::text AS category`;
  const customerNameSelect = ordersColumns?.has('customer_name')
    ? 'customer_name AS customer_name'
    : `''::text AS customer_name`;
  const notesSelect = ordersColumns?.has('notes') ? 'notes' : `''::text AS notes`;
  const imageUrlSelect = ordersColumns?.has('image_url') ? 'image_url AS image_url' : `''::text AS image_url`;
  const audioUrlSelect = ordersColumns?.has('audio_url') ? 'audio_url AS audio_url' : `''::text AS audio_url`;

  let sql = `
    SELECT tracking_code AS tracking_code,
           drug_name AS drug_name,
           quantity,
           status,
           ${categorySelect},
           ${customerNameSelect},
           ${notesSelect},
           ${imageUrlSelect},
           ${audioUrlSelect},
           created_at AS created_at,
           user_id AS user_id
    FROM orders
  `;
  if (where.length > 0) {
    sql += ` WHERE ${where.join(' AND ')}`;
  }
  sql += ' ORDER BY created_at DESC';
  const { rows } = await db.query(sql, params);
  const header = [
    'tracking_code',
    'drug_name',
    'quantity',
    'status',
    'category',
    'customer_name',
    'notes',
    'image_url',
    'audio_url',
    'created_at',
    'user_id',
  ];
  const csvRows = [
    header.join(','),
    ...rows.map((r) =>
      [
        csvEscape(r.tracking_code),
        csvEscape(r.drug_name),
        csvEscape(r.quantity),
        csvEscape(r.status),
        csvEscape(r.category),
        csvEscape(r.customer_name),
        csvEscape(r.notes),
        csvEscape(r.image_url),
        csvEscape(r.audio_url),
        csvEscape(r.created_at ? new Date(r.created_at).toISOString() : ''),
        csvEscape(r.user_id || ''),
      ].join(','),
    ),
  ];
  res.set('Content-Type', 'text/csv; charset=utf-8');
  res.set('Content-Disposition', 'attachment; filename=\"orders.csv\"');
  return res.send(csvRows.join('\\n'));
}));

const buildOrderRecord = ({ base, now = new Date().toISOString() }) => ({
  id: randomUUID(),
  trackingCode: makeTracking(),
  drugId: base.drugId || null,
  drugName: base.drugName,
  quantity: Number.isFinite(Number(base.quantity)) ? Number(base.quantity) : 1,
  userId: base.userId || null,
  status: ORDER_STATUSES[0],
  category: base.category && ORDER_CATEGORIES.includes(base.category) ? base.category : ORDER_CATEGORIES[0],
  customerName: base.customerName ? base.customerName.toString().trim() : '',
  notes: base.notes ? base.notes.toString().trim() : '',
  imageUrl: base.imageUrl ? base.imageUrl.toString().trim() : '',
  audioUrl: base.audioUrl ? base.audioUrl.toString().trim() : '',
  createdAt: now,
});

const insertOrder = async ({ user, drugId, drugName, quantity = 1, customerName = '', notes = '', imageUrl = '', audioUrl = '', category = '' }) => {
  let resolvedName = drugName ? drugName.toString().trim() : '';
  let resolvedDrugId = null;
  if (drugId) {
    const { rows: drugRows } = await db.query('SELECT id, name FROM drugs WHERE id=$1', [drugId]);
    if (drugRows.length === 0) {
      return { error: 'دارو یافت نشد.' };
    }
    resolvedDrugId = drugRows[0].id;
    resolvedName = drugRows[0].name;
  }
  if (!resolvedName) {
    return { error: 'نام دارو الزامی است.' };
  }
  if (category && !ORDER_CATEGORIES.includes(category)) {
    return { error: 'نوع درخواست نامعتبر است.' };
  }
  const order = buildOrderRecord({
    base: {
      drugId: resolvedDrugId,
      drugName: resolvedName,
      quantity,
      userId: user ? user.id : null,
      customerName,
      notes,
      imageUrl,
      audioUrl,
      category,
    },
  });
  if (!ordersColumns) {
    await ensureOrdersSchema();
  }
  const cols = ordersColumns || new Set();
  const fields = ['id', 'tracking_code', 'drug_id', 'drug_name', 'quantity', 'user_id', 'status'];
  const values = [order.id, order.trackingCode, order.drugId, order.drugName, order.quantity, order.userId, order.status];
  if (cols.has('category')) {
    fields.push('category');
    values.push(order.category);
  }
  if (cols.has('customer_name')) {
    fields.push('customer_name');
    values.push(order.customerName);
  }
  if (cols.has('notes')) {
    fields.push('notes');
    values.push(order.notes);
  }
  if (cols.has('image_url')) {
    fields.push('image_url');
    values.push(order.imageUrl);
  }
  if (cols.has('audio_url')) {
    fields.push('audio_url');
    values.push(order.audioUrl);
  }
  fields.push('created_at');
  values.push(order.createdAt);
  const placeholders = values.map((_, idx) => `$${idx + 1}`).join(',');
  await db.query(
    `INSERT INTO orders (${fields.join(', ')})
     VALUES (${placeholders})`,
    values,
  );
  return { order };
};

app.post('/api/orders', asyncHandler(async (req, res) => {
  const user = await getUserFromRequest(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  const {
    drugId,
    drugName = '',
    quantity = 1,
    customerName = '',
    notes = '',
    imageUrl = '',
    audioUrl = '',
    category = '',
  } = req.body || {};
  const { order, error } = await insertOrder({
    user,
    drugId,
    drugName,
    quantity,
    customerName,
    notes,
    imageUrl,
    audioUrl,
    category,
  });
  if (error) return res.status(400).json({ message: error });
  try {
    const { rows: adminRows } = await db.query(`SELECT id FROM users WHERE role = 'admin'`);
    const adminIds = adminRows.map((r) => r.id);
    const title = 'سفارش جدید';
    const body = `${order.drugName} x${order.quantity} (کد: ${order.trackingCode})`;
    await notifyUsers({
      userIds: adminIds,
      type: 'order_created',
      title,
      body,
      data: { orderId: order.id, trackingCode: order.trackingCode },
    });
    await notifyUsers({
      userIds: [user.id],
      type: 'order_created',
      title: 'ثبت سفارش',
      body: `سفارش شما ثبت شد (کد: ${order.trackingCode})`,
      data: { orderId: order.id, trackingCode: order.trackingCode },
    });
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to create order notification', err);
  }
  return res.status(201).json({ data: order });
}));

app.post('/api/orders/:id/status', requireAdmin, asyncHandler(async (req, res) => {
  const { status } = req.body || {};
  if (!ORDER_STATUSES.includes(status)) {
    return res.status(400).json({ message: 'وضعیت نامعتبر است.' });
  }
  const { rows: existing } = await db.query('SELECT * FROM orders WHERE id=$1', [req.params.id]);
  if (!existing[0]) {
    return res.status(404).json({ message: 'سفارش یافت نشد.' });
  }
  const order = existing[0];
  await db.query('UPDATE orders SET status=$2 WHERE id=$1', [order.id, status]);
  if (order.user_id) {
    try {
      const title = 'تغییر وضعیت سفارش';
      const body = `سفارش ${order.tracking_code} به "${status}" تغییر کرد.`;
      await notifyUsers({
        userIds: [order.user_id],
        type: 'order_status',
        title,
        body,
        data: { orderId: order.id, trackingCode: order.tracking_code, status },
      });
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error('Failed to notify order status', err);
    }
  }
  return res.json({ data: { id: order.id, status } });
}));

app.post('/api/special-requests', asyncHandler(async (req, res) => {
  const user = await getUserFromRequest(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  const {
    drugName,
    description = '',
    customerName = '',
    notes = '',
    imageUrl = '',
    audioUrl = '',
    category = '',
  } = req.body || {};
  const combinedNotes = [description, notes]
    .map((n) => (n ? n.toString().trim() : ''))
    .filter(Boolean)
    .join('\n');
  const { order, error } = await insertOrder({
    user,
    drugName,
    quantity: 1,
    customerName,
    notes: combinedNotes,
    imageUrl,
    audioUrl,
    category,
  });
  if (error) return res.status(400).json({ message: error });
  try {
    const { rows: adminRows } = await db.query(`SELECT id FROM users WHERE role = 'admin'`);
    const adminIds = adminRows.map((r) => r.id);
    const title = 'درخواست ویژه';
    const body = `${order.drugName} (کد: ${order.trackingCode})`;
    await notifyUsers({
      userIds: adminIds,
      type: 'special_request_created',
      title,
      body,
      data: { orderId: order.id, trackingCode: order.trackingCode },
    });
    await notifyUsers({
      userIds: [user.id],
      type: 'special_request_created',
      title: 'ثبت درخواست ویژه',
      body: `درخواست شما ثبت شد (کد: ${order.trackingCode})`,
      data: { orderId: order.id, trackingCode: order.trackingCode },
    });
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to create special request notification', err);
  }
  return res.status(201).json({ data: order });
}));

// --- Chat endpoints ---
const loadThreadById = async (threadId) => {
  const { rows } = await db.query('SELECT * FROM chat_threads WHERE id = $1', [threadId]);
  return rows[0] || null;
};

const userCanAccessThread = (user, thread) => {
  if (!thread || !user) return false;
  if (user.role === 'admin') return true;
  return thread.client_id === user.id;
};

app.get('/api/chat/threads', asyncHandler(async (req, res) => {
  const user = await getUserFromRequest(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  if (user.role !== 'admin' && user.role !== 'colleague') {
    return res.status(403).json({ message: 'Colleagues only' });
  }

  const query = user.role === 'admin'
    ? `
      SELECT ct.*, u.first_name AS client_first_name, u.last_name AS client_last_name,
        (SELECT body FROM chat_messages WHERE thread_id = ct.id ORDER BY created_at DESC LIMIT 1) AS last_message,
        (SELECT created_at FROM chat_messages WHERE thread_id = ct.id ORDER BY created_at DESC LIMIT 1) AS last_message_created_at,
        (SELECT COUNT(*) FROM chat_messages WHERE thread_id = ct.id AND sender_role = 'client' AND is_read = false) AS unread_count
      FROM chat_threads ct
      JOIN users u ON u.id = ct.client_id
      WHERE u.role = 'colleague'
        AND EXISTS (SELECT 1 FROM chat_messages WHERE thread_id = ct.id)
      ORDER BY ct.updated_at DESC
    `
    : `
      SELECT ct.*, u.first_name AS client_first_name, u.last_name AS client_last_name,
        (SELECT body FROM chat_messages WHERE thread_id = ct.id ORDER BY created_at DESC LIMIT 1) AS last_message,
        (SELECT created_at FROM chat_messages WHERE thread_id = ct.id ORDER BY created_at DESC LIMIT 1) AS last_message_created_at,
        (SELECT COUNT(*) FROM chat_messages WHERE thread_id = ct.id AND sender_role = 'admin' AND is_read = false) AS unread_count
      FROM chat_threads ct
      JOIN users u ON u.id = ct.client_id
      WHERE ct.client_id = $1
      ORDER BY ct.updated_at DESC
    `;

  const { rows } = await db.query(query, user.role === 'admin' ? [] : [user.id]);
  return res.json({ data: rows.map(serializeThreadRow) });
}));

app.get('/api/chat/unread-count', asyncHandler(async (req, res) => {
  const user = await getUserFromRequest(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  if (user.role !== 'admin' && user.role !== 'colleague') {
    return res.status(403).json({ message: 'Colleagues only' });
  }
  const count = await getUnreadChatCountByUserId(user.id);
  return res.json({ count });
}));

app.get('/api/badges', asyncHandler(async (req, res) => {
  const user = await getUserFromRequest(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  const [notifications, orders, chat] = await Promise.all([
    getUnreadNotificationsCount(user.id),
    getUnreadOrderNotificationsCount(user.id),
    getUnreadChatCountByUserId(user.id),
  ]);
  return res.json({
    notifications,
    orders,
    chat,
    total: notifications + chat,
  });
}));

app.post('/api/chat/threads', asyncHandler(async (req, res) => {
  const user = await getUserFromRequest(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  if (user.role === 'admin') {
    return res.status(400).json({ message: 'Admins cannot open client threads.' });
  }
  if (user.role !== 'colleague') {
    return res.status(403).json({ message: 'Colleagues only' });
  }

  // Reuse open thread if exists
  const existing = await db.query(
    'SELECT * FROM chat_threads WHERE client_id = $1 AND status = $2 ORDER BY updated_at DESC LIMIT 1',
    [user.id, 'open'],
  );
  if (existing.rows[0]) {
    return res.status(200).json({ data: serializeThreadRow(existing.rows[0]) });
  }

  const threadId = randomUUID();
  const now = new Date().toISOString();
  await db.query(
    `INSERT INTO chat_threads (id, client_id, status, created_at, updated_at)
     VALUES ($1,$2,'open',$3,$3)`,
    [threadId, user.id, now],
  );
  const thread = await loadThreadById(threadId);
  return res.status(201).json({ data: serializeThreadRow(thread) });
}));

app.get('/api/chat/threads/:id/messages', asyncHandler(async (req, res) => {
  const user = await getUserFromRequest(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  if (user.role !== 'admin' && user.role !== 'colleague') {
    return res.status(403).json({ message: 'Colleagues only' });
  }
  const thread = await loadThreadById(req.params.id);
  if (!userCanAccessThread(user, thread)) {
    return res.status(403).json({ message: 'Access denied' });
  }
  const senderRoleToMarkRead = user.role === 'admin' ? 'client' : 'admin';
  await db.query(
    'UPDATE chat_messages SET is_read = true WHERE thread_id = $1 AND sender_role = $2 AND is_read = false',
    [thread.id, senderRoleToMarkRead],
  );
  const { rows } = await db.query(
    'SELECT * FROM chat_messages WHERE thread_id = $1 ORDER BY created_at ASC',
    [thread.id],
  );
  return res.json({ data: rows.map(serializeMessageRow) });
}));

app.post('/api/chat/threads/:id/messages', asyncHandler(async (req, res) => {
  const user = await getUserFromRequest(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  if (user.role !== 'admin' && user.role !== 'colleague') {
    return res.status(403).json({ message: 'Colleagues only' });
  }
  const thread = await loadThreadById(req.params.id);
  if (!userCanAccessThread(user, thread)) {
    return res.status(403).json({ message: 'Access denied' });
  }
  const { body = '', audioBase64 = '' } = req.body || {};
  if ((!body || typeof body !== 'string' || !body.trim()) && !audioBase64) {
    return res.status(400).json({ message: 'پیام نمی‌تواند خالی باشد.' });
  }
  let attachmentUrl = '';
  if (audioBase64) {
    try {
      attachmentUrl = saveBase64Audio(audioBase64);
    } catch (err) {
      return res.status(400).json({ message: 'ذخیره فایل صوتی ناموفق بود.' });
    }
  }
  const messageBody = body && body.trim() ? body.trim() : attachmentUrl ? 'پیام صوتی' : '';
  const messageId = randomUUID();
  const now = new Date().toISOString();
  await db.query(
    `INSERT INTO chat_messages (id, thread_id, sender_id, sender_role, body, attachment_url, created_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [
      messageId,
      thread.id,
      user.id,
      user.role === 'admin' ? 'admin' : 'client',
      messageBody,
      attachmentUrl,
      now,
    ],
  );
  await db.query('UPDATE chat_threads SET updated_at = $2 WHERE id = $1', [thread.id, now]);
  const { rows } = await db.query('SELECT * FROM chat_messages WHERE id = $1', [messageId]);
  try {
    const isAdmin = user.role === 'admin';
    const title = 'پیام جدید';
    const bodyText = messageBody.length > 120 ? `${messageBody.slice(0, 117)}...` : messageBody;
    if (isAdmin) {
      await notifyUsers({
        userIds: [thread.client_id],
        type: 'chat_message',
        title,
        body: bodyText,
        data: { threadId: thread.id, messageId },
      });
    } else {
      const { rows: adminRows } = await db.query(`SELECT id FROM users WHERE role = 'admin'`);
      await notifyUsers({
        userIds: adminRows.map((r) => r.id),
        type: 'chat_message',
        title,
        body: bodyText,
        data: { threadId: thread.id, messageId },
      });
    }
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to notify chat message', err);
  }
  return res.status(201).json({ data: serializeMessageRow(rows[0]) });
}));

app.use((err, _req, res, _next) => {
  // eslint-disable-next-line no-console
  console.error('Unhandled API error', err);
  if (res.headersSent) return;
  res.status(500).json({ message: 'Server error.' });
});

const startServer = async () => {
  await ensureSchema();
  await ensureAdminUser();
  app.listen(PORT, HOST, () => {
    // eslint-disable-next-line no-console
    const displayHost = HOST === '0.0.0.0' ? 'localhost' : HOST;
    console.log(
      `API listening on http://${displayHost}:${PORT} (Android emulator: http://10.0.2.2:${PORT})`,
    );
  });
};

startServer().catch((err) => {
  // eslint-disable-next-line no-console
  console.error('Failed to start server', err);
  process.exit(1);
});
