-- Schema for DaroCheck backend (PostgreSQL)
-- Enables UUID generation for primary keys.
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Clean existing tables (drop children before parents).
DROP TABLE IF EXISTS phone_verification_codes;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS user_push_tokens;
DROP TABLE IF EXISTS chat_messages;
DROP TABLE IF EXISTS chat_threads;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS drugs;

-- Drugs catalog.
CREATE TABLE IF NOT EXISTS drugs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  description TEXT DEFAULT '',
  stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Users for authentication.
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  username TEXT NOT NULL UNIQUE,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  phone_verified BOOLEAN NOT NULL DEFAULT FALSE,
  role TEXT NOT NULL DEFAULT 'user',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Orders placed for existing drugs.
CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tracking_code TEXT NOT NULL,
  drug_id UUID REFERENCES drugs(id) ON DELETE SET NULL,
  drug_name TEXT NOT NULL, -- can be free-text when no catalog entry exists
  quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'در حال بررسی' CHECK (status IN ('در حال بررسی','یافت شد','ارسال شد','تکمیل','لغو')),
  category TEXT NOT NULL DEFAULT 'دارو' CHECK (category IN ('دارو','مکمل','تجهیزات','لوازم مصرفی','درخواست ویژه')),
  customer_name TEXT DEFAULT '',
  notes TEXT DEFAULT '',
  image_url TEXT DEFAULT '',
  audio_url TEXT DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (tracking_code)
);

-- Chat threads between clients and admins.
CREATE TABLE IF NOT EXISTS chat_threads (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  admin_id UUID REFERENCES users(id),
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','closed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Chat messages tied to a thread.
CREATE TABLE IF NOT EXISTS chat_messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  thread_id UUID NOT NULL REFERENCES chat_threads(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  sender_role TEXT NOT NULL CHECK (sender_role IN ('client','admin')),
  body TEXT NOT NULL,
  attachment_url TEXT DEFAULT '',
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_chat_messages_thread_created
  ON chat_messages(thread_id, created_at);

CREATE INDEX IF NOT EXISTS idx_chat_threads_client_updated
  ON chat_threads(client_id, updated_at);

-- Pending phone verification codes (one active per user).
CREATE TABLE IF NOT EXISTS phone_verification_codes (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  code CHAR(4) NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (user_id)
);

-- Push tokens for mobile notifications.
CREATE TABLE IF NOT EXISTS user_push_tokens (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token TEXT NOT NULL UNIQUE,
  platform TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_user_push_tokens_user
  ON user_push_tokens(user_id, updated_at DESC);

-- In-app notifications (orders, chat, etc).
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  title TEXT NOT NULL DEFAULT '',
  body TEXT NOT NULL DEFAULT '',
  data JSONB NOT NULL DEFAULT '{}'::jsonb,
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_notifications_user_unread_created
  ON notifications(user_id, is_read, created_at DESC);

-- --- Safe migrations for existing databases ---
-- If you already have data and only need to add missing columns, run these instead of dropping tables:
-- ALTER TABLE orders ADD COLUMN IF NOT EXISTS category TEXT NOT NULL DEFAULT 'دارو';
-- ALTER TABLE orders ADD COLUMN IF NOT EXISTS customer_name TEXT NOT NULL DEFAULT '';
-- ALTER TABLE orders ADD COLUMN IF NOT EXISTS notes TEXT NOT NULL DEFAULT '';
-- ALTER TABLE orders ADD COLUMN IF NOT EXISTS image_url TEXT NOT NULL DEFAULT '';
-- ALTER TABLE orders ADD COLUMN IF NOT EXISTS audio_url TEXT NOT NULL DEFAULT '';
-- CREATE TABLE IF NOT EXISTS user_push_tokens (...);
-- CREATE TABLE IF NOT EXISTS notifications (...);
