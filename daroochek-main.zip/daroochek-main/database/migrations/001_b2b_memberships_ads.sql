-- DaroCheck: B2B colleague onboarding, memberships and ad inventory.
-- Additive migration: safe to apply to an existing database.

CREATE TABLE IF NOT EXISTS colleague_profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  business_name TEXT NOT NULL,
  business_type TEXT NOT NULL DEFAULT 'pharmacy',
  license_number TEXT NOT NULL DEFAULT '',
  city TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL DEFAULT '',
  contact_name TEXT NOT NULL DEFAULT '',
  review_status TEXT NOT NULL DEFAULT 'pending' CHECK (review_status IN ('pending','approved','rejected')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS membership_plans (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  price_amount BIGINT NOT NULL DEFAULT 0 CHECK (price_amount >= 0),
  currency TEXT NOT NULL DEFAULT 'IRR',
  duration_days INTEGER NOT NULL DEFAULT 30 CHECK (duration_days > 0),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS memberships (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan_id UUID NOT NULL REFERENCES membership_plans(id),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','active','expired','cancelled','failed')),
  payment_provider TEXT NOT NULL DEFAULT '',
  payment_reference TEXT NOT NULL DEFAULT '',
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_memberships_user_status ON memberships(user_id, status, ends_at DESC);

CREATE TABLE IF NOT EXISTS ad_slots (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  placement TEXT NOT NULL,
  size_label TEXT NOT NULL DEFAULT '',
  base_price_amount BIGINT NOT NULL DEFAULT 0 CHECK (base_price_amount >= 0),
  is_active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS advertisements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slot_id UUID NOT NULL REFERENCES ad_slots(id) ON DELETE RESTRICT,
  advertiser_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL DEFAULT '',
  image_url TEXT NOT NULL DEFAULT '',
  target_url TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','pending','approved','running','paused','ended','rejected')),
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_advertisements_slot_status_dates ON advertisements(slot_id, status, starts_at, ends_at);

INSERT INTO membership_plans (code, name, description, price_amount, currency, duration_days)
VALUES
  ('colleague-basic', 'عضویت همکار پایه', 'دسترسی به ثبت همکاری و ارتباط عملیاتی', 0, 'IRR', 30),
  ('colleague-pro', 'عضویت همکار حرفه‌ای', 'جایگاه بهتر و امکانات بیشتر برای داروخانه‌ها', 0, 'IRR', 30)
ON CONFLICT (code) DO NOTHING;

INSERT INTO ad_slots (code, name, placement, size_label, base_price_amount)
VALUES
  ('home-hero', 'تبلیغ قهرمان صفحه اول', 'home.hero', 'large', 0),
  ('home-top-small', 'تبلیغ کوچک بالای صفحه', 'home.top', 'small', 0),
  ('home-inline', 'تبلیغ میانی صفحه', 'home.inline', 'medium', 0)
ON CONFLICT (code) DO NOTHING;
