# داروچک

داروچک یک پلتفرم فارسی RTL برای ثبت و پیگیری درخواست دارو و اتصال داروخانه‌ها/همکاران به تقاضای واقعی است.

## ساختار واحد repository

- `lib/`: اپ Flutter کاربر و مدیر
- `server/`: API Node/Express و احراز هویت
- `database/schema.sql`: baseline دیتابیس
- `database/migrations/`: migrationهای افزایشی Supabase/Postgres، جدا از کد
- `netlify-site/`: landing page B2B و صفحه اول برند برای Netlify
- `docs/`: راهنمای محیط، معماری و استقرار
- `plan.md` و `TODO.md`: تصمیم‌های معماری و وضعیت کار

## اجرا

### Backend

```bash
cd server
npm install
npm start
```

Backend به `DATABASE_URL` نیاز دارد. قرارداد کامل متغیرها در `.env.example` و `docs/DEPLOYMENT.md` است. وابستگی‌های واقعی backend شامل `express`, `cors`, `jsonwebtoken` و `pg` هستند.

### Flutter

```bash
flutter pub get
flutter run --dart-define=API_URL=http://localhost:4000
```

برای Android Emulator از `http://10.0.2.2:4000` استفاده کنید. برای Firebase Push، فایل‌های محیطی Android/iOS را خارج از repository و در محیط امن تنظیم کنید.

### Landing / Netlify

`netlify.toml` خروجی `netlify-site/` را منتشر می‌کند. این landing، backend موبایل را جایگزین نمی‌کند و برای معرفی برند، تبلیغات B2B و ورود همکاران است.

```bash
# پیش‌نمایش ساده
python3 -m http.server 8080 --directory netlify-site
```

## قابلیت‌های داده‌ای آماده

Migration `database/migrations/001_b2b_memberships_ads.sql` مدل‌های زیر را اضافه می‌کند:

- پروفایل جداگانه همکار/داروخانه و وضعیت بررسی
- پلن عضویت و رکورد عضویت با وضعیت پرداخت
- جایگاه‌های تبلیغاتی بزرگ، کوچک و میانی
- آگهی‌های زمان‌دار با وضعیت انتشار

APIهای مربوط به این مدل‌ها در `server/index.js` قرار گرفته‌اند: `/api/partner/profile`, `/api/membership/plans`, `/api/memberships` و `/api/ads`.

> اتصال درگاه پرداخت واقعی هنوز نیازمند انتخاب ارائه‌دهنده و secretهای محیطی آن است؛ هیچ کلید یا مقدار ساختگی در کد قرار داده نشده است.
