package com.example.darocheck

import android.content.Context
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import me.leolin.shortcutbadger.ShortcutBadger

class MainActivity : FlutterActivity() {
    private val badgeChannelName = "com.example.darocheck/badge"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, badgeChannelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "setBadge" -> {
                    val count = call.argument<Int>("count") ?: 0
                    setBadgeCount(this, count)
                    result.success(null)
                }

                "clearBadge" -> {
                    setBadgeCount(this, 0)
                    result.success(null)
                }

                else -> result.notImplemented()
            }
        }
    }

    private fun setBadgeCount(context: Context, count: Int) {
        try {
            if (count <= 0) {
                ShortcutBadger.removeCount(context)
            } else {
                ShortcutBadger.applyCount(context, count)
            }
        } catch (_: Throwable) {
            // Some launchers/devices do not support badges.
        }
    }
}
