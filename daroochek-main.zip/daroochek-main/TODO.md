# داروچک — وضعیت کارها

- [x] repository واحد شامل Flutter، backend، schema و landing page داشته باشد.
- [x] وابستگی‌های واقعی backend (`jsonwebtoken` و `pg`) در `server/package.json` ثبت شوند.
- [x] فایل‌های Supabase/Postgres در `database/migrations/` جدا از کد application نگهداری شوند.
- [x] مدل داده برای پروفایل همکار، عضویت و جایگاه‌های تبلیغاتی اضافه شود.
- [x] landing page فارسی RTL با hero، تبلیغات بزرگ/کوچک و CTA همکار برای Netlify آماده شود.
- [ ] اجرای migration روی پروژه Supabase `darochek` پس از فعال بودن پروژه و بررسی هزینه/دسترسی.
- [ ] اتصال درگاه پرداخت واقعی؛ نیازمند انتخاب ارائه‌دهنده و کلیدهای محیطی.
- [ ] افزودن onboarding کامل همکار در Flutter با فرم کسب‌وکار و وضعیت عضویت.
- [ ] فعال‌سازی Firebase config برای Android/iOS در محیط امن.
- [ ] اجرای `flutter analyze`, `flutter test` و build در runner دارای Flutter SDK.
- [ ] اتصال Netlify و انتشار سایت پس از رفع احراز هویت Netlify.
