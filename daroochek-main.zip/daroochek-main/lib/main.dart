import 'dart:convert';
import 'dart:async';
import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:mime/mime.dart';
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';

import 'push_manager.dart';

class BadgeRefreshBus {
  static final ValueNotifier<int> tick = ValueNotifier<int>(0);
  static void request() => tick.value++;
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await PushManager.instance.init();
  runApp(const DaroCheckRoot());
}

class DaroCheckRoot extends StatefulWidget {
  const DaroCheckRoot({super.key});

  @override
  State<DaroCheckRoot> createState() => _DaroCheckRootState();
}

class _DaroCheckRootState extends State<DaroCheckRoot> {
  final ApiClient _api = ApiClient();
  UserProfile? _user;
  bool _restoringSession = true;

  @override
  void initState() {
    super.initState();
    _restoreSession();
  }

  Future<void> _restoreSession() async {
    try {
      final user = await _api.restoreSession();
      if (!mounted) return;
      if (user != null) {
        PushManager.instance.bindRegistrar(({required token, required platform}) {
          return _api.registerPushToken(token: token, platform: platform);
        });
      }
      setState(() {
        _user = user;
        _restoringSession = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _restoringSession = false);
    }
  }

  void _handleAuthenticated(UserProfile user) {
    PushManager.instance.bindRegistrar(({required token, required platform}) {
      return _api.registerPushToken(token: token, platform: platform);
    });
    setState(() => _user = user);
  }

  void _handleLogout() {
    _api.logout();
    PushManager.instance.unbindRegistrar();
    unawaited(PushManager.instance.updateAppBadge(0));
    setState(() => _user = null);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'دارو چک',
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        );
      },
      theme: ThemeData(
        colorSchemeSeed: Colors.teal,
        useMaterial3: true,
      ),
      home: _restoringSession
          ? const _SplashScreen()
          : LandingScreen(
              api: _api,
              user: _user,
              onAuthenticated: _handleAuthenticated,
              onLogout: _handleLogout,
            ),
    );
  }
}

enum AuthStep { login, signup, verify }

class _SplashScreen extends StatelessWidget {
  const _SplashScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/brand/darochek-splash.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.black.withOpacity(.18), const Color(0xFF061B1A).withOpacity(.92)],
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 104,
                height: 104,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF09211F).withOpacity(.72),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: const Color(0xFFB9FFD7).withOpacity(.35)),
                  boxShadow: [BoxShadow(color: const Color(0xFF35D399).withOpacity(.24), blurRadius: 34)],
                ),
                child: Image.asset('assets/brand/darochek-mark.png'),
              ),
              const SizedBox(height: 22),
              const Text('داروچک', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w900)),
              const SizedBox(height: 7),
              const Text('داروی کمیاب، مسیر روشن.', style: TextStyle(color: Color(0xFFB9FFD7), fontSize: 13)),
              const SizedBox(height: 28),
              const SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFFB9FFD7))),
              const SizedBox(height: 12),
              Text('در حال اتصال به شبکه همکاران', style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 11)),
            ],
          ),
        ),
      ),
    );
  }
}

class LandingScreen extends StatelessWidget {
  const LandingScreen({
    super.key,
    required this.api,
    required this.user,
    required this.onAuthenticated,
    required this.onLogout,
  });

  final ApiClient api;
  final UserProfile? user;
  final ValueChanged<UserProfile> onAuthenticated;
  final VoidCallback onLogout;

  @override
  Widget build(BuildContext context) {
    if (user != null) {
      return HomeShell(
        api: api,
        user: user!,
        onLogout: onLogout,
      );
    }
    return AuthScreen(api: api, onAuthenticated: onAuthenticated);
  }
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key, required this.api, required this.onAuthenticated});

  final ApiClient api;
  final ValueChanged<UserProfile> onAuthenticated;

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  AuthStep _step = AuthStep.login;
  bool _submitting = false;
  String? _error;
  String? _pendingUsername;
  String? _devCodeHint;
  String? _devLoginCodeHint;
  bool _loginWithPassword = true;
  String _signupRole = 'user';

  final _loginPassCtrl = TextEditingController();
  final _loginPhoneCtrl = TextEditingController();
  final _loginPhoneCodeCtrl = TextEditingController();

  final _firstNameCtrl = TextEditingController();
  final _lastNameCtrl = TextEditingController();
  final _signupPhoneCtrl = TextEditingController();
  final _signupPassCtrl = TextEditingController();

  final _verifyUserCtrl = TextEditingController();
  final _verifyCodeCtrl = TextEditingController();

  @override
  void dispose() {
    _loginPassCtrl.dispose();
    _firstNameCtrl.dispose();
    _lastNameCtrl.dispose();
    _signupPhoneCtrl.dispose();
    _signupPassCtrl.dispose();
    _verifyUserCtrl.dispose();
    _verifyCodeCtrl.dispose();
    _loginPhoneCtrl.dispose();
    _loginPhoneCodeCtrl.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    final username = _loginPhoneCtrl.text.trim();
    final password = _loginPassCtrl.text;
    if (username.isEmpty || password.isEmpty) {
      setState(() => _error = 'شماره موبایل و رمز عبور را وارد کنید');
      return;
    }
    setState(() {
      _submitting = true;
      _error = null;
    });
    try {
      final user = await widget.api.login(
        phone: username,
        password: password,
      );
      widget.onAuthenticated(user);
      if (mounted && Navigator.of(context).canPop()) Navigator.of(context).pop();
    } catch (err) {
      setState(() => _error = _messageFromError(err, fallback: 'ورود ناموفق بود'));
    } finally {
      setState(() => _submitting = false);
    }
  }

  Future<void> _requestLoginCode() async {
    final phone = _loginPhoneCtrl.text.trim();
    if (phone.isEmpty) {
      setState(() => _error = 'شماره موبایل را وارد کنید');
      return;
    }
    setState(() {
      _submitting = true;
      _error = null;
    });
    try {
      final result = await widget.api.requestLoginCode(phone: phone);
      setState(() {
        _devLoginCodeHint = result.devCode;
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('کد ورود ارسال شد')),
      );
    } catch (err) {
      setState(() => _error = _messageFromError(err, fallback: 'ارسال کد ناموفق بود'));
    } finally {
      setState(() => _submitting = false);
    }
  }

  Future<void> _loginWithCode() async {
    final phone = _loginPhoneCtrl.text.trim();
    final code = _loginPhoneCodeCtrl.text.trim();
    if (phone.isEmpty || code.isEmpty) {
      setState(() => _error = 'شماره و کد را وارد کنید');
      return;
    }
    setState(() {
      _submitting = true;
      _error = null;
    });
    try {
      final user = await widget.api.loginWithCode(phone: phone, code: code);
      widget.onAuthenticated(user);
      if (mounted && Navigator.of(context).canPop()) Navigator.of(context).pop();
    } catch (err) {
      setState(() => _error = _messageFromError(err, fallback: 'ورود ناموفق بود'));
    } finally {
      setState(() => _submitting = false);
    }
  }

  Future<void> _register() async {
    if ([
      _firstNameCtrl.text.trim(),
      _lastNameCtrl.text.trim(),
      _signupPhoneCtrl.text.trim(),
      _signupPassCtrl.text,
    ].any((e) => e.isEmpty)) {
      setState(() => _error = 'همه فیلدها الزامی هستند');
      return;
    }
    setState(() {
      _submitting = true;
      _error = null;
    });
    try {
      final result = await widget.api.register(
        firstName: _firstNameCtrl.text.trim(),
        lastName: _lastNameCtrl.text.trim(),
        phone: _signupPhoneCtrl.text.trim(),
        password: _signupPassCtrl.text,
        role: _signupRole,
      );
      if (result.pendingVerification) {
        setState(() {
          _pendingUsername = result.username;
          _devCodeHint = result.devCode;
          _verifyUserCtrl.text = result.username ?? _signupPhoneCtrl.text.trim();
          _step = AuthStep.verify;
        });
      } else if (result.user != null) {
        widget.onAuthenticated(result.user!);
        if (mounted && Navigator.of(context).canPop()) Navigator.of(context).pop();
      }
    } catch (err) {
      setState(() => _error = _messageFromError(err, fallback: 'ثبت‌نام ناموفق بود'));
    } finally {
      setState(() => _submitting = false);
    }
  }

  Future<void> _verify() async {
    final username =
        _verifyUserCtrl.text.trim().isNotEmpty ? _verifyUserCtrl.text.trim() : (_pendingUsername ?? '');
    if (username.isEmpty || _verifyCodeCtrl.text.trim().isEmpty) {
      setState(() => _error = 'شماره موبایل و کد تایید الزامی است');
      return;
    }
    setState(() {
      _submitting = true;
      _error = null;
    });
    try {
      final user = await widget.api.verifyCode(
        username: username,
        code: _verifyCodeCtrl.text.trim(),
      );
      widget.onAuthenticated(user);
      if (mounted && Navigator.of(context).canPop()) Navigator.of(context).pop();
    } catch (err) {
      setState(() => _error = _messageFromError(err, fallback: 'کد تایید نامعتبر است'));
    } finally {
      setState(() => _submitting = false);
    }
  }

  String _messageFromError(Object err, {required String fallback}) {
    if (err is ApiException && err.message.isNotEmpty) return err.message;
    if (err is SocketException) {
      final api = widget.api.baseUrl;
      if (!kIsWeb && Platform.isAndroid) {
        return 'عدم اتصال به سرور ($api). اگر روی امولاتور اندروید هستید از 10.0.2.2 به جای localhost استفاده کنید.';
      }
      return 'عدم اتصال به سرور ($api).';
    }
    if (err is TimeoutException) {
      return 'اتصال به سرور با تأخیر مواجه شد. دوباره تلاش کنید.';
    }
    return fallback;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ورود / ثبت‌نام')),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 250),
                    child: _buildStep(),
                  ),
                  if (_error != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: Text(
                        _error!,
                        style: const TextStyle(color: Colors.red),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStep() {
    switch (_step) {
      case AuthStep.login:
        return _LoginChoiceForm(
          key: const ValueKey('loginChoice'),
          submitting: _submitting,
          usePassword: _loginWithPassword,
          onToggle: (value) => setState(() => _loginWithPassword = value),
          passCtrl: _loginPassCtrl,
          phoneCtrl: _loginPhoneCtrl,
          codeCtrl: _loginPhoneCodeCtrl,
          onSendCode: _requestLoginCode,
          onSubmitPassword: _login,
          onSubmitCode: _loginWithCode,
          devCodeHint: _devLoginCodeHint,
          onGoSignup: () => setState(() => _step = AuthStep.signup),
        );
      case AuthStep.signup:
        return _SignupForm(
          key: const ValueKey('signup'),
          submitting: _submitting,
          onSubmit: _register,
          onSwitch: () => setState(() => _step = AuthStep.login),
          firstNameCtrl: _firstNameCtrl,
          lastNameCtrl: _lastNameCtrl,
          phoneCtrl: _signupPhoneCtrl,
          passCtrl: _signupPassCtrl,
          selectedRole: _signupRole,
          onRoleChanged: (value) => setState(() => _signupRole = value),
        );
      case AuthStep.verify:
        return _VerifyForm(
          key: const ValueKey('verify'),
          submitting: _submitting,
          onSubmit: _verify,
          username: _pendingUsername,
          userCtrl: _verifyUserCtrl,
          codeCtrl: _verifyCodeCtrl,
          devCodeHint: _devCodeHint,
        );
    }
  }
}

class _LoginChoiceForm extends StatelessWidget {
  const _LoginChoiceForm({
    super.key,
    required this.submitting,
    required this.usePassword,
    required this.onToggle,
    required this.passCtrl,
    required this.phoneCtrl,
    required this.codeCtrl,
    required this.onSendCode,
    required this.onSubmitPassword,
    required this.onSubmitCode,
    required this.onGoSignup,
    this.devCodeHint,
  });

  final bool submitting;
  final bool usePassword;
  final ValueChanged<bool> onToggle;
  final TextEditingController passCtrl;
  final TextEditingController phoneCtrl;
  final TextEditingController codeCtrl;
  final VoidCallback onSendCode;
  final VoidCallback onSubmitPassword;
  final VoidCallback onSubmitCode;
  final VoidCallback onGoSignup;
  final String? devCodeHint;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'ورود به حساب کاربری',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            const Text('شماره موبایل خود را وارد کنید'),
            const SizedBox(height: 12),
            Wrap(
              spacing: 12,
              runSpacing: 8,
              alignment: WrapAlignment.center,
              children: [
                _toggleChip(
                  label: 'ورود با رمز عبور',
                  selected: usePassword,
                  onTap: () => onToggle(true),
                ),
                _toggleChip(
                  label: 'ورود با رمز یکبارمصرف',
                  selected: !usePassword,
                  onTap: () => onToggle(false),
                ),
              ],
            ),
            const SizedBox(height: 16),
            if (usePassword) ...[
              TextField(
                controller: phoneCtrl,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: 'شماره همراه وارد نمایید',
                  prefixIcon: Icon(Icons.phone_iphone),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: passCtrl,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'کلمه عبور وارد نمایید',
                  prefixIcon: Icon(Icons.lock_outline),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              _primaryButton(
                submitting: submitting,
                label: 'ورود',
                onPressed: submitting ? null : onSubmitPassword,
              ),
            ] else ...[
              TextField(
                controller: phoneCtrl,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: 'شماره همراه وارد نمایید',
                  prefixIcon: Icon(Icons.phone_iphone),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: codeCtrl,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        labelText: 'کد ۴ رقمی',
                        prefixIcon: const Icon(Icons.sms_outlined),
                        border: const OutlineInputBorder(),
                        helperText: devCodeHint != null ? 'کد تست: $devCodeHint' : null,
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  ElevatedButton(
                    onPressed: submitting ? null : onSendCode,
                    child: const Text('ارسال کد'),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              _primaryButton(
                submitting: submitting,
                label: 'ورود',
                onPressed: submitting ? null : onSubmitCode,
              ),
            ],
            const SizedBox(height: 12),
            TextButton(
              onPressed: submitting ? null : onGoSignup,
              child: const Text('ثبت‌نام'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _toggleChip({
    required String label,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? Colors.teal.shade50 : Colors.grey.shade200,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: selected ? Colors.teal : Colors.grey.shade300),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Radio<bool>(
              value: true,
              groupValue: selected,
              onChanged: (_) => onTap(),
              activeColor: Colors.teal,
            ),
            Text(label, style: TextStyle(color: selected ? Colors.black : Colors.grey.shade700)),
          ],
        ),
      ),
    );
  }

  Widget _primaryButton({
    required bool submitting,
    required String label,
    required VoidCallback? onPressed,
  }) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 14),
          backgroundColor: Colors.green.shade600,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        onPressed: onPressed,
        child: submitting
            ? const SizedBox(
                height: 18,
                width: 18,
                child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
              )
            : Text(label),
      ),
    );
  }
}

class _SignupForm extends StatelessWidget {
  const _SignupForm({
    super.key,
    required this.submitting,
    required this.onSubmit,
    required this.onSwitch,
    required this.firstNameCtrl,
    required this.lastNameCtrl,
    required this.phoneCtrl,
    required this.passCtrl,
    required this.selectedRole,
    required this.onRoleChanged,
  });

  final bool submitting;
  final VoidCallback onSubmit;
  final VoidCallback onSwitch;
  final TextEditingController firstNameCtrl;
  final TextEditingController lastNameCtrl;
  final TextEditingController phoneCtrl;
  final TextEditingController passCtrl;
  final String selectedRole;
  final ValueChanged<String> onRoleChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      key: key,
      children: [
        const Text(
          'ثبت‌نام',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: firstNameCtrl,
          keyboardType: TextInputType.name,
          textAlign: TextAlign.right,
          decoration: const InputDecoration(
            labelText: 'نام',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: lastNameCtrl,
          keyboardType: TextInputType.name,
          textAlign: TextAlign.right,
          decoration: const InputDecoration(
            labelText: 'نام خانوادگی',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: phoneCtrl,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(
            labelText: 'شماره موبایل',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 4,
          children: [
            ChoiceChip(
              label: const Text('کاربر عادی'),
              selected: selectedRole == 'user',
              onSelected: (_) => onRoleChanged('user'),
            ),
            ChoiceChip(
              label: const Text('همکار'),
              selected: selectedRole == 'colleague',
              onSelected: (_) => onRoleChanged('colleague'),
            ),
            ChoiceChip(
              label: const Text('پذیرش / مرکز درمانی'),
              selected: selectedRole == 'reception',
              onSelected: (_) => onRoleChanged('reception'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        TextField(
          controller: passCtrl,
          obscureText: true,
          decoration: const InputDecoration(
            labelText: 'رمز عبور',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        ElevatedButton(
          onPressed: submitting ? null : onSubmit,
          child: submitting
              ? const SizedBox(
                  height: 18,
                  width: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Text('ثبت‌نام'),
        ),
        TextButton(
          onPressed: submitting ? null : onSwitch,
          child: const Text('بازگشت به ورود'),
        ),
      ],
    );
  }
}

class _VerifyForm extends StatelessWidget {
  const _VerifyForm({
    super.key,
    required this.submitting,
    required this.onSubmit,
    required this.username,
    required this.userCtrl,
    required this.codeCtrl,
    this.devCodeHint,
  });

  final bool submitting;
  final VoidCallback onSubmit;
  final String? username;
  final TextEditingController userCtrl;
  final TextEditingController codeCtrl;
  final String? devCodeHint;

  @override
  Widget build(BuildContext context) {
    return Column(
      key: key,
      children: [
        const Text(
          'تایید شماره',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: userCtrl,
          decoration: InputDecoration(
            labelText: 'شماره موبایل',
            hintText: username,
            border: const OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: codeCtrl,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(
            labelText: 'کد ۴ رقمی',
            border: const OutlineInputBorder(),
            helperText: devCodeHint != null ? 'کد برای تست: $devCodeHint' : null,
          ),
        ),
        const SizedBox(height: 12),
        ElevatedButton(
          onPressed: submitting ? null : onSubmit,
          child: submitting
              ? const SizedBox(
                  height: 18,
                  width: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Text('تایید'),
        ),
      ],
    );
  }
}

const LinearGradient _daroGreenGradient = LinearGradient(
  begin: Alignment.topCenter,
  end: Alignment.bottomCenter,
  stops: [0.0, 0.55, 1.0],
  colors: [
    Color(0xFF0A6B5E),
    Color(0xFF0C8C79),
    Color(0xFF075B50),
  ],
);

class DaroGradientBackground extends StatelessWidget {
  const DaroGradientBackground({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(gradient: _daroGreenGradient),
      child: SizedBox.expand(child: child),
    );
  }
}

class DaroPanel extends StatelessWidget {
  const DaroPanel({super.key, required this.child, this.margin = const EdgeInsets.all(16)});

  final Widget child;
  final EdgeInsetsGeometry margin;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: margin,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Material(
          color: Colors.white.withOpacity(0.92),
          child: child,
        ),
      ),
    );
  }
}

class DaroGradientButton extends StatelessWidget {
  const DaroGradientButton({
    super.key,
    required this.text,
    required this.onPressed,
    this.loading = false,
    this.width,
  });

  final String text;
  final VoidCallback? onPressed;
  final bool loading;
  final double? width;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: 56,
      child: ElevatedButton(
        onPressed: loading ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          padding: EdgeInsets.zero,
          shape: const StadiumBorder(),
        ),
        child: Ink(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.greenAccent.shade200, Colors.green.shade600],
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.greenAccent.withOpacity(0.25),
                blurRadius: 24,
                spreadRadius: 2,
                offset: const Offset(0, 10),
              ),
            ],
            borderRadius: BorderRadius.circular(999),
          ),
          child: Center(
            child: loading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                  )
                : Text(
                    text,
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Colors.white),
                  ),
          ),
        ),
      ),
    );
  }
}

class _StoredSession {
  const _StoredSession({
    required this.refreshToken,
    this.token,
    this.user,
  });

  final String refreshToken;
  final String? token;
  final Map<String, dynamic>? user;
}

class SessionStore {
  static const String _fileName = 'darocheck_session.json';

  const SessionStore();

  Future<File?> _file() async {
    if (kIsWeb) return null;
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/$_fileName');
  }

  Future<_StoredSession?> load() async {
    final file = await _file();
    if (file == null) return null;
    try {
      if (!await file.exists()) return null;
      final raw = await file.readAsString();
      final data = jsonDecode(raw) as Map<String, dynamic>;
      final refreshToken = (data['refreshToken'] ?? '').toString().trim();
      if (refreshToken.isEmpty) return null;
      final token = (data['token'] ?? '').toString().trim();
      final user = data['user'] is Map ? Map<String, dynamic>.from(data['user'] as Map) : null;
      return _StoredSession(refreshToken: refreshToken, token: token.isEmpty ? null : token, user: user);
    } catch (_) {
      return null;
    }
  }

  Future<void> save({
    required String refreshToken,
    required String token,
    required Map<String, dynamic> user,
  }) async {
    final file = await _file();
    if (file == null) return;
    final payload = jsonEncode({
      'refreshToken': refreshToken,
      'token': token,
      'user': user,
      'savedAt': DateTime.now().toIso8601String(),
    });
    await file.writeAsString(payload, flush: true);
  }

  Future<void> clear() async {
    final file = await _file();
    if (file == null) return;
    try {
      if (await file.exists()) {
        await file.delete();
      }
    } catch (_) {
      // ignore
    }
  }
}

class _UserNavItem {
  const _UserNavItem({
    required this.title,
    required this.icon,
    required this.page,
    this.badgeCount = 0,
  });

  final String title;
  final IconData icon;
  final Widget page;
  final int badgeCount;
}


class HomeShell extends StatefulWidget {
  const HomeShell({
    super.key,
    required this.api,
    required this.user,
    required this.onLogout,
  });

  final ApiClient api;
  final UserProfile user;
  final VoidCallback onLogout;

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> with SingleTickerProviderStateMixin {
  int _index = 0;
  Timer? _pollTimer;
  bool _polling = false;
  int _unreadChatCount = 0;
  int _unreadNotificationsCount = 0;
  int _unreadOrderNotificationsCount = 0;
  bool _countsLoaded = false;

  void _onBadgeRefreshRequested() {
    _pollCounts();
  }

  @override
  void initState() {
    super.initState();
    _pollCounts();
    _pollTimer = Timer.periodic(const Duration(seconds: 15), (_) => _pollCounts());
    BadgeRefreshBus.tick.addListener(_onBadgeRefreshRequested);
  }

  @override
  void didUpdateWidget(covariant HomeShell oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.user.id != widget.user.id) {
      _unreadChatCount = 0;
      _unreadNotificationsCount = 0;
      _pollCounts();
    }
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    BadgeRefreshBus.tick.removeListener(_onBadgeRefreshRequested);
    super.dispose();
  }

  Future<void> _pollCounts() async {
    if (_polling) return;
    _polling = true;
    try {
      final badges = await widget.api.fetchBadges();
      final prevNotifications = _unreadNotificationsCount;
      final prevChat = _unreadChatCount;
      if (!mounted) return;
      setState(() {
        _unreadNotificationsCount = badges.notifications;
        _unreadOrderNotificationsCount = badges.orders;
        _unreadChatCount = badges.chat;
      });
      await PushManager.instance.updateAppBadge(badges.total);

      if (_countsLoaded) {
        final newNotifications = badges.notifications - prevNotifications;
        final newChats = badges.chat - prevChat;
        if (newNotifications > 0) {
          await PushManager.instance.showLocalNotification(
            title: 'اعلان جدید',
            body: 'شما $newNotifications اعلان جدید دارید.',
          );
        }
        if (newChats > 0) {
          await PushManager.instance.showLocalNotification(
            title: 'پیام جدید',
            body: 'شما $newChats پیام جدید دارید.',
          );
        }
      } else {
        _countsLoaded = true;
      }
    } catch (_) {
      // ignore polling errors
    } finally {
      _polling = false;
    }
  }

  Widget _iconWithBadge(IconData icon, int count) {
    if (count <= 0) return Icon(icon);
    final label = count > 99 ? '99+' : '$count';
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Icon(icon),
        Positioned(
          right: -6,
          top: -4,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
            decoration: BoxDecoration(
              color: Colors.red,
              borderRadius: BorderRadius.circular(10),
            ),
            constraints: const BoxConstraints(minWidth: 16),
            child: Text(
              label,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final isAdmin = widget.user.role == 'admin';
    final isColleague = widget.user.role == 'colleague';
    final user = widget.user;

    if (isAdmin) {
      final navItems = [
        _UserNavItem(
          title: 'صفحه اصلی',
          icon: Icons.dashboard_outlined,
          badgeCount: _unreadNotificationsCount,
          page: AdminPanel(api: widget.api),
        ),
        _UserNavItem(
          title: 'چت',
          icon: Icons.chat_bubble_outline,
          badgeCount: _unreadChatCount,
          page: ChatThreadsPage(api: widget.api, user: user, isAdmin: true, usePanel: true),
        ),
        _UserNavItem(
          title: 'سفارش‌ها',
          icon: Icons.list_alt,
          badgeCount: _unreadOrderNotificationsCount,
          page: AdminOrdersPage(api: widget.api, usePanel: true),
        ),
      ];

      if (_index >= navItems.length) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) setState(() => _index = 0);
        });
      }
      final safeIndex = _index >= navItems.length ? 0 : _index;
      final title = safeIndex == 0 ? '' : navItems[safeIndex].title;

      return Scaffold(
        extendBodyBehindAppBar: true,
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          title: title.isEmpty ? null : Text(title),
          backgroundColor: Colors.transparent,
          surfaceTintColor: Colors.transparent,
          elevation: 0,
          foregroundColor: Colors.white,
          centerTitle: true,
        ),
        drawer: Drawer(
          child: SafeArea(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                DrawerHeader(
                  decoration: const BoxDecoration(gradient: _daroGreenGradient),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.admin_panel_settings_outlined, color: Colors.white),
                          const SizedBox(width: 8),
                          const Text(
                            'پنل مدیریت',
                            style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        '${widget.user.firstName} ${widget.user.lastName}'.trim().isEmpty
                            ? widget.user.username
                            : '${widget.user.firstName} ${widget.user.lastName}'.trim(),
                        style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        widget.user.phone,
                        style: TextStyle(color: Colors.white.withOpacity(0.85)),
                      ),
                    ],
                  ),
                ),
                ...navItems.asMap().entries.map(
                      (entry) => ListTile(
                        selected: safeIndex == entry.key,
                        leading: entry.value.badgeCount > 0
                            ? _iconWithBadge(entry.value.icon, entry.value.badgeCount)
                            : Icon(entry.value.icon),
                        title: Text(entry.value.title),
                        onTap: () {
                          setState(() => _index = entry.key);
                          Navigator.of(context).pop();
                        },
                      ),
                    ),
                const Divider(),
                ListTile(
                  leading: const Icon(Icons.logout),
                  title: const Text('خروج'),
                  onTap: () {
                    Navigator.of(context).pop();
                    widget.onLogout();
                  },
                ),
              ],
            ),
          ),
        ),
        body: DaroGradientBackground(
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(top: kToolbarHeight),
              child: navItems[safeIndex].page,
            ),
          ),
        ),
      );
    }

    final navItems = [
      _UserNavItem(
        title: 'خانه',
        icon: Icons.home_outlined,
        page: DaroHomePage(api: widget.api, user: user),
      ),
      _UserNavItem(
        title: 'اعلان‌ها',
        icon: Icons.notifications_none,
        badgeCount: _unreadNotificationsCount,
        page: NotificationsPage(api: widget.api),
      ),
      _UserNavItem(
        title: 'کشف',
        icon: Icons.explore_outlined,
        page: const DaroDiscoverPage(),
      ),
      _UserNavItem(
        title: 'سفارش‌های من',
        icon: Icons.receipt_long,
        badgeCount: _unreadOrderNotificationsCount,
        page: OrdersPage(api: widget.api, title: 'سفارش‌های من', usePanel: true),
      ),
      _UserNavItem(
        title: 'پروفایل',
        icon: Icons.person_outline,
        page: DaroProfilePage(user: user, onLogout: widget.onLogout),
      ),
      if (isColleague)
        _UserNavItem(
          title: 'چت',
          icon: Icons.chat_bubble_outline,
          badgeCount: _unreadChatCount,
          page: ChatThreadsPage(api: widget.api, user: user, isAdmin: false, usePanel: true),
        ),
    ];

    if (_index >= navItems.length) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) setState(() => _index = 0);
      });
    }
    final safeIndex = _index >= navItems.length ? 0 : _index;
    final title = safeIndex == 0 ? '' : navItems[safeIndex].title;

    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: title.isEmpty ? null : Text(title),
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.white,
        centerTitle: true,
      ),
      drawer: Drawer(
        child: SafeArea(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              DrawerHeader(
                decoration: const BoxDecoration(gradient: _daroGreenGradient),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.local_pharmacy_rounded, color: Colors.white),
                        const SizedBox(width: 8),
                        const Text(
                          'داروچک',
                          style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Text(
                      '${widget.user.firstName} ${widget.user.lastName}'.trim().isEmpty
                          ? widget.user.username
                          : '${widget.user.firstName} ${widget.user.lastName}'.trim(),
                      style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      widget.user.phone,
                      style: TextStyle(color: Colors.white.withOpacity(0.85)),
                    ),
                  ],
                ),
              ),
              ...navItems.asMap().entries.map(
                    (entry) => ListTile(
                      selected: safeIndex == entry.key,
                      leading: entry.value.badgeCount > 0
                          ? _iconWithBadge(entry.value.icon, entry.value.badgeCount)
                          : Icon(entry.value.icon),
                      title: Text(entry.value.title),
                      onTap: () {
                        setState(() => _index = entry.key);
                        Navigator.of(context).pop();
                      },
                    ),
                  ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.logout),
                title: const Text('خروج'),
                onTap: () {
                  Navigator.of(context).pop();
                  widget.onLogout();
                },
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: safeIndex,
        backgroundColor: Colors.white,
        indicatorColor: const Color(0xFFB9FFD7),
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: navItems.map((item) => NavigationDestination(
          icon: _iconWithBadge(item.icon, item.badgeCount),
          selectedIcon: _iconWithBadge(item.icon, item.badgeCount),
          label: item.title,
        )).toList(),
      ),
      body: DaroGradientBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.only(top: kToolbarHeight),
            child: navItems[safeIndex].page,
          ),
        ),
      ),
    );
  }
}


class DaroHomePage extends StatelessWidget {
  const DaroHomePage({super.key, required this.api, required this.user});

  final ApiClient api;
  final UserProfile user;

  static const _ink = Color(0xFF09211F);
  static const _mint = Color(0xFFB9FFD7);
  static const _coral = Color(0xFFFF866B);
  static const _gold = Color(0xFFF4C76B);

  void _openRequest(BuildContext context) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => Scaffold(
        backgroundColor: _ink,
        appBar: AppBar(
          title: const Text('ثبت درخواست دارو'),
          backgroundColor: _ink,
          foregroundColor: Colors.white,
        ),
        body: UserHome(api: api, canRequestSpecial: true),
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final firstName = user.firstName.trim().isEmpty ? 'همراه' : user.firstName.trim();
    return Container(
      color: const Color(0xFFF7FAF8),
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(child: _topBar(context, firstName)),
          SliverToBoxAdapter(child: _hero(context)),
          SliverToBoxAdapter(child: _sectionTitle('دسته‌بندی خدمات', 'هر چیزی که لازم داری، همین‌جاست')),
          SliverToBoxAdapter(child: _categories(context)),
          SliverToBoxAdapter(child: _sponsoredCard(context)),
          SliverToBoxAdapter(child: _sectionTitle('برای مراکز درمانی', 'پذیرش و همکاری حرفه‌ای')),
          SliverToBoxAdapter(child: _providerCards(context)),
          SliverToBoxAdapter(child: _partnerBanner(context)),
          const SliverToBoxAdapter(child: SizedBox(height: 32)),
        ],
      ),
    );
  }

  Widget _topBar(BuildContext context, String firstName) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 12),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              padding: const EdgeInsets.all(7),
              decoration: BoxDecoration(color: _ink, borderRadius: BorderRadius.circular(14)),
              child: Image.asset('assets/brand/darochek-mark.png'),
            ),
            const SizedBox(width: 10),
            const Text('داروچک', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: _ink)),
            const Spacer(),
            Text('تهران', style: TextStyle(color: _ink.withOpacity(.7), fontWeight: FontWeight.w700)),
            const Icon(Icons.keyboard_arrow_down_rounded, color: _ink),
            const SizedBox(width: 8),
            _roundIcon(Icons.search_rounded, () => _openRequest(context)),
          ],
        ),
      );

  Widget _hero(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Container(
          height: 188,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            image: const DecorationImage(image: AssetImage('assets/brand/darochek-splash.jpg'), fit: BoxFit.cover),
            boxShadow: [BoxShadow(color: _ink.withOpacity(.18), blurRadius: 22, offset: const Offset(0, 10))],
          ),
          child: Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(28),
              gradient: LinearGradient(colors: [_ink.withOpacity(.97), _ink.withOpacity(.45), Colors.transparent]),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('دارو تو بسپار به ما', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.w900)),
              const SizedBox(height: 7),
              Text('شبکه داروچک دنبالش می‌گرده', style: TextStyle(color: Colors.white.withOpacity(.78), fontSize: 13)),
              const Spacer(),
              ElevatedButton.icon(
                onPressed: () => _openRequest(context),
                icon: const Icon(Icons.arrow_back_rounded, size: 18),
                label: const Text('ثبت درخواست'),
                style: ElevatedButton.styleFrom(backgroundColor: _coral, foregroundColor: Colors.white, shape: const StadiumBorder(), padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12)),
              ),
            ]),
          ),
        ),
      );

  Widget _sectionTitle(String title, String subtitle) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 25, 18, 12),
        child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: _ink)),
            const SizedBox(height: 3),
            Text(subtitle, style: TextStyle(fontSize: 11, color: _ink.withOpacity(.55))),
          ])),
          Text('بیشتر', style: TextStyle(color: _coral, fontSize: 12, fontWeight: FontWeight.w800)),
        ]),
      );

  Widget _categories(BuildContext context) {
    final items = [
      ('پوست و مو', Icons.face_retouching_natural_rounded, _coral),
      ('دندان‌پزشکی', Icons.sentiment_satisfied_alt_rounded, _gold),
      ('مراکز زیبایی', Icons.spa_rounded, const Color(0xFFBE8C69)),
      ('آزمایشگاه‌ها', Icons.biotech_rounded, const Color(0xFF5D9CA1)),
      ('درمانگاه', Icons.medical_services_rounded, const Color(0xFF70967D)),
      ('بیشتر', Icons.grid_view_rounded, _ink),
    ];
    return SizedBox(height: 106, child: ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 16), scrollDirection: Axis.horizontal,
      itemCount: items.length, separatorBuilder: (_, __) => const SizedBox(width: 14),
      itemBuilder: (_, i) { final item = items[i]; return SizedBox(width: 72, child: Column(children: [
        Container(width: 64, height: 64, decoration: BoxDecoration(shape: BoxShape.circle, color: (item.$3 as Color).withOpacity(.13), border: Border.all(color: (item.$3 as Color).withOpacity(.28), width: 2)), child: Icon(item.$2, color: item.$3, size: 29)),
        const SizedBox(height: 6), Text(item.$1, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: _ink)),
      ]); });
  }

  Widget _sponsoredCard(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
        child: Container(
          height: 260,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(26), image: const DecorationImage(image: AssetImage('assets/brand/darochek-splash.jpg'), fit: BoxFit.cover)),
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(26), gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.black.withOpacity(.1), Colors.black.withOpacity(.82)])),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(color: Colors.white.withOpacity(.18), borderRadius: BorderRadius.circular(20)), child: const Text('Sponsored', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700))), const Spacer(), const Icon(Icons.volume_off_rounded, color: Colors.white70)]),
              const Spacer(), const Text('کلینیک‌های منتخب داروچک', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 4), const Text('بهترین انتخاب برای سلامت و زیبایی', style: TextStyle(color: Colors.white70, fontSize: 12)),
              const SizedBox(height: 14), OutlinedButton(onPressed: () {}, style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white70), shape: const StadiumBorder()), child: const Text('مشاهده پروفایل')),
            ]),
          ),
        ),
      );

  Widget _providerCards(BuildContext context) => SizedBox(height: 178, child: ListView.separated(
    padding: const EdgeInsets.symmetric(horizontal: 16), scrollDirection: Axis.horizontal, itemCount: 3,
    separatorBuilder: (_, __) => const SizedBox(width: 12), itemBuilder: (_, i) {
      final data = [('آزمایشگاه‌های معتبر', Icons.biotech_rounded, 'نتیجه سریع و آنلاین'), ('کلینیک دندانپزشکی', Icons.health_and_safety_rounded, 'وقت‌دهی آسان'), ('درمانگاه شبانه‌روزی', Icons.local_hospital_rounded, 'نزدیک شما')][i];
      return Container(width: 220, padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), border: Border.all(color: _ink.withOpacity(.08)), boxShadow: [BoxShadow(color: _ink.withOpacity(.05), blurRadius: 18, offset: const Offset(0, 8))]), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(width: 45, height: 45, decoration: BoxDecoration(color: _mint.withOpacity(.7), borderRadius: BorderRadius.circular(14)), child: Icon(data.$2, color: _ink)), const Spacer(), Text(data.$1, style: const TextStyle(color: _ink, fontSize: 14, fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(data.$3, style: TextStyle(color: _ink.withOpacity(.55), fontSize: 11)),
      ]);
    },
  ));

  Widget _partnerBanner(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 26, 16, 0),
        child: InkWell(onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const DaroPartnerPage())), borderRadius: BorderRadius.circular(24), child: Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: _ink, borderRadius: BorderRadius.circular(24)), child: Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('برای کسب‌وکارها', style: TextStyle(color: _gold, fontSize: 11, fontWeight: FontWeight.w800)), const SizedBox(height: 8), const Text('به شبکه داروچک بپیوندید', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900)), const SizedBox(height: 6), Text('کلینیک، آزمایشگاه یا داروخانه‌تان را حرفه‌ای معرفی کنید.', style: TextStyle(color: Colors.white.withOpacity(.66), fontSize: 11, height: 1.6))]), const Icon(Icons.arrow_back_rounded, color: _mint, size: 28),
        ]))));

  Widget _roundIcon(IconData icon, VoidCallback onTap) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(99), child: Container(width: 42, height: 42, decoration: BoxDecoration(color: _ink.withOpacity(.08), shape: BoxShape.circle), child: Icon(icon, color: _ink)));
}

class DaroDiscoverPage extends StatelessWidget {
  const DaroDiscoverPage({super.key});
  @override
  Widget build(BuildContext context) => Container(color: const Color(0xFFF7FAF8), child: ListView(padding: const EdgeInsets.all(20), children: const [Text('کشف خدمات', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: Color(0xFF09211F))), SizedBox(height: 8), Text('از مراکز معتبر اطراف تا خدمات سلامت و زیبایی را پیدا کنید.', style: TextStyle(color: Colors.black54)), SizedBox(height: 24), DaroInfoTile(icon: Icons.location_on_outlined, title: 'نزدیک‌ترین مراکز', subtitle: 'کلینیک‌ها و آزمایشگاه‌های اطراف شما'), DaroInfoTile(icon: Icons.verified_outlined, title: 'همکاران تأییدشده', subtitle: 'فقط پروفایل‌های بررسی‌شده داروچک'), DaroInfoTile(icon: Icons.calendar_month_outlined, title: 'رزرو و پذیرش', subtitle: 'درخواست نوبت از مسیر روشن') ]));
}

class DaroInfoTile extends StatelessWidget {
  const DaroInfoTile({super.key, required this.icon, required this.title, required this.subtitle});
  final IconData icon; final String title; final String subtitle;
  @override
  Widget build(BuildContext context) => Card(margin: const EdgeInsets.only(bottom: 12), elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)), child: ListTile(contentPadding: const EdgeInsets.all(12), leading: CircleAvatar(backgroundColor: const Color(0xFFB9FFD7), foregroundColor: const Color(0xFF09211F), child: Icon(icon)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text(subtitle));
}

class DaroProfilePage extends StatelessWidget {
  const DaroProfilePage({super.key, required this.user, required this.onLogout});
  final UserProfile user; final VoidCallback onLogout;
  @override
  Widget build(BuildContext context) => Container(color: const Color(0xFFF7FAF8), child: ListView(padding: const EdgeInsets.all(20), children: [const Text('پروفایل من', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: Color(0xFF09211F))), const SizedBox(height: 20), CircleAvatar(radius: 38, backgroundColor: const Color(0xFFB9FFD7), foregroundColor: const Color(0xFF09211F), child: Text(user.firstName.isEmpty ? 'د' : user.firstName.characters.first, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900))), const SizedBox(height: 12), Center(child: Text('${user.firstName} ${user.lastName}'.trim().isEmpty ? user.username : '${user.firstName} ${user.lastName}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))), const SizedBox(height: 24), DaroInfoTile(icon: Icons.phone_outlined, title: 'شماره موبایل', subtitle: user.phone), DaroInfoTile(icon: Icons.badge_outlined, title: 'کد کاربری', subtitle: user.username), const SizedBox(height: 10), OutlinedButton.icon(onPressed: onLogout, icon: const Icon(Icons.logout), label: const Text('خروج از حساب'))]));
}

class DaroPartnerPage extends StatelessWidget {
  const DaroPartnerPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(backgroundColor: const Color(0xFF09211F), appBar: AppBar(backgroundColor: Colors.transparent, foregroundColor: Colors.white, title: const Text('عضویت همکاران')), body: ListView(padding: const EdgeInsets.all(22), children: [const SizedBox(height: 12), const Text('کسب‌وکارتان را به شبکه‌ای سریع‌تر وصل کنید.', style: TextStyle(color: Colors.white, fontSize: 29, fontWeight: FontWeight.w900, height: 1.25)), const SizedBox(height: 14), Text('داروخانه، کلینیک، آزمایشگاه و درمانگاه؛ یک پروفایل حرفه‌ای بسازید و از تقاضای واقعی بازار دیده شوید.', style: TextStyle(color: Colors.white70, height: 1.8)), const SizedBox(height: 28), ...['داروخانه و مرکز پخش', 'کلینیک و درمانگاه', 'آزمایشگاه و مرکز تشخیص'].map((label) => Card(color: Colors.white.withOpacity(.08), elevation: 0, child: ListTile(leading: const Icon(Icons.verified_outlined, color: Color(0xFFB9FFD7)), title: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)), trailing: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white70, size: 16)))), const SizedBox(height: 24), ElevatedButton(onPressed: () => Navigator.of(context).pop(), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFB9FFD7), foregroundColor: const Color(0xFF09211F), minimumSize: const Size.fromHeight(54), shape: const StadiumBorder()), child: const Text('شروع ثبت‌نام همکار', style: TextStyle(fontWeight: FontWeight.w900))) ]));
}

class UserHome extends StatefulWidget {
  const UserHome({
    super.key,
    required this.api,
    this.showLoginButton = false,
    this.onLoginTap,
    this.canRequestSpecial = false,
  });

  final ApiClient api;
  final bool showLoginButton;
  final VoidCallback? onLoginTap;
  final bool canRequestSpecial;

  @override
  State<UserHome> createState() => _UserHomeState();
}

class _UserHomeState extends State<UserHome> {
  final TextEditingController _quickCtrl = TextEditingController();
  final TextEditingController _descCtrl = TextEditingController();
  bool _submitting = false;
  bool _showDetails = false;

  final ImagePicker _picker = ImagePicker();
  String? _imageDataUrl;
  String? _audioBase64;
  final AudioRecorder _voiceRecorder = AudioRecorder();
  bool _recordingAudio = false;
  // Keep client-side limit lower than server to fail fast before upload.
  static const int _maxImageBytes = 8 * 1024 * 1024; // 8 MB

  @override
  void dispose() {
    _quickCtrl.dispose();
    _descCtrl.dispose();
    _imageDataUrl = null;
    _audioBase64 = null;
    if (_recordingAudio) {
      _voiceRecorder.stop();
    }
    _voiceRecorder.dispose();
    super.dispose();
  }

  String _errMsg(Object err, String fallback) {
    if (err is ApiException && err.message.isNotEmpty) return err.message;
    return fallback;
  }

  Future<void> _pickImage({required bool fromCamera}) async {
    try {
      final XFile? file = await _picker.pickImage(
        source: fromCamera ? ImageSource.camera : ImageSource.gallery,
        imageQuality: 80,
      );
      if (file == null) return;
      final bytes = await file.readAsBytes();
      if (bytes.length > _maxImageBytes) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('حجم تصویر بیش از حد مجاز است (حداکثر ۸ مگابایت).')),
          );
        }
        return;
      }
      final mime = lookupMimeType(file.name) ?? 'image/jpeg';
      setState(() {
        _imageDataUrl = 'data:$mime;base64,${base64Encode(bytes)}';
      });
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('انتخاب تصویر ناموفق بود')),
      );
    }
  }

  Future<void> _startVoiceRecording() async {
    try {
      if (!await _voiceRecorder.hasPermission()) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('دسترسی به میکروفون داده نشد')),
        );
        return;
      }
      final dir = await getTemporaryDirectory();
      final path = '${dir.path}/home_voice_${DateTime.now().millisecondsSinceEpoch}.m4a';
      await _voiceRecorder.start(
        const RecordConfig(
          encoder: AudioEncoder.aacLc,
          bitRate: 128000,
          sampleRate: 44100,
        ),
        path: path,
      );
      setState(() {
        _recordingAudio = true;
        _audioBase64 = null;
      });
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('شروع ضبط صدا ممکن نشد')),
      );
    }
  }

  Future<void> _stopVoiceRecording() async {
    try {
      final path = await _voiceRecorder.stop();
      setState(() => _recordingAudio = false);
      if (path != null) {
        final bytes = await File(path).readAsBytes();
        setState(() => _audioBase64 = base64Encode(bytes));
      }
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('ذخیره صدای ضبط‌شده ممکن نشد')),
      );
    }
  }

  void _clearAudio() {
    setState(() => _audioBase64 = null);
  }

  Future<void> _submitQuickRequest() async {
    if (!widget.canRequestSpecial) return;
    final text = _quickCtrl.text.trim();
    if (text.isEmpty) {
      _showSnack('نام دارو یا توضیح را وارد کنید.');
      return;
    }
    if (!_showDetails) {
      setState(() => _showDetails = true);
      return;
    }
    setState(() => _submitting = true);
    try {
      final result = await widget.api.createSpecialRequest(
        CreateSpecialRequest(
          drugName: text,
          category: 'درخواست ویژه',
          description: _descCtrl.text.trim(),
          customerName: '',
          notes: '',
          imageUrl: _imageDataUrl ?? '',
          audioUrl: _audioBase64 ?? '',
        ),
      );
      if (!mounted) return;
      _quickCtrl.clear();
      _descCtrl.clear();
      setState(() {
        _showDetails = false;
        _imageDataUrl = null;
        _audioBase64 = null;
      });
      _showSnack('درخواست ثبت شد. کد پیگیری: ${result.trackingCode}');
    } catch (err) {
      if (!mounted) return;
      _showSnack(_errMsg(err, 'ثبت درخواست ناموفق بود'));
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  void _showSnack(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text)),
    );
  }

  Widget _featureItem(IconData icon, String label) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: Colors.white.withOpacity(0.9), size: 28),
        const SizedBox(height: 6),
        Text(
          label,
          style: TextStyle(
            color: Colors.white.withOpacity(0.9),
            fontSize: 12,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final contentMaxWidth = constraints.maxWidth - 48; // horizontal padding (24 * 2)
        final safeContentWidth = contentMaxWidth < 0 ? 0.0 : contentMaxWidth;
        final buttonWidth = safeContentWidth > 240 ? 240.0 : safeContentWidth;
        return SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: ConstrainedBox(
            constraints: BoxConstraints(minHeight: constraints.maxHeight - 16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  children: [
                    const SizedBox(height: 6),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 32,
                          height: 32,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.22),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(Icons.local_pharmacy_rounded, color: Colors.white),
                        ),
                        const SizedBox(width: 10),
                        const Text(
                          'داروچک',
                          style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800),
                        ),
                      ],
                    ),
                    const SizedBox(height: 56),
                    const Text(
                      'پیداش می‌کنیم',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 44,
                        height: 1.1,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'داروی کمیابت رو بسپار به ما',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.white.withOpacity(0.88),
                      ),
                    ),
                    const SizedBox(height: 52),
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.95),
                        borderRadius: BorderRadius.circular(999),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.08),
                            blurRadius: 24,
                            offset: const Offset(0, 10),
                          ),
                        ],
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 18),
                      child: TextField(
                        controller: _quickCtrl,
                        textInputAction: TextInputAction.done,
                        onSubmitted: (_) => _submitQuickRequest(),
                        decoration: const InputDecoration(
                          hintText: 'اسم دارو یا هر توضیحی داری بنویس...',
                          border: InputBorder.none,
                        ),
                      ),
                    ),
                    if (_showDetails) ...[
                      const SizedBox(height: 12),
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.95),
                          borderRadius: BorderRadius.circular(18),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.06),
                              blurRadius: 22,
                              offset: const Offset(0, 10),
                            ),
                          ],
                        ),
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                        child: TextField(
                          controller: _descCtrl,
                          minLines: 2,
                          maxLines: 4,
                          decoration: const InputDecoration(
                            hintText: 'توضیحات تکمیلی...',
                            border: InputBorder.none,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Align(
                        alignment: Alignment.center,
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 260),
                          child: OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.white,
                              side: BorderSide(color: Colors.white.withOpacity(0.65)),
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                              shape: const StadiumBorder(),
                            ),
                            onPressed: () => _pickImage(fromCamera: true),
                            icon: const Icon(Icons.camera_alt_rounded),
                            label: const Text('ارسال تصویر'),
                          ),
                        ),
                      ),
                      if (_imageDataUrl != null) ...[
                        const SizedBox(height: 8),
                        Align(
                          alignment: Alignment.center,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Container(
                              color: Colors.white.withOpacity(0.92),
                              padding: const EdgeInsets.all(8),
                              child: Image.memory(
                                base64Decode(_imageDataUrl!.split(',').last),
                                height: 160,
                                width: 260,
                                fit: BoxFit.contain,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 6),
                        TextButton.icon(
                          onPressed: () => setState(() => _imageDataUrl = null),
                          icon: const Icon(Icons.close, color: Colors.white),
                          label: const Text('حذف تصویر', style: TextStyle(color: Colors.white)),
                        ),
                      ],
                      const SizedBox(height: 6),
                      Align(
                        alignment: Alignment.center,
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 260),
                          child: OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.white,
                              side: BorderSide(color: Colors.white.withOpacity(0.65)),
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                              shape: const StadiumBorder(),
                            ),
                            onPressed: _recordingAudio ? _stopVoiceRecording : _startVoiceRecording,
                            icon: Icon(_recordingAudio ? Icons.stop_circle_outlined : Icons.mic_none),
                            label: Text(_recordingAudio ? 'پایان ضبط' : 'ارسال صدا'),
                          ),
                        ),
                      ),
                      if (_audioBase64 != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 6),
                          child: Column(
                            children: [
                              Text(
                                'صدای شما آماده ارسال است',
                                style: TextStyle(color: Colors.white.withOpacity(0.9)),
                              ),
                              TextButton.icon(
                                onPressed: _clearAudio,
                                icon: const Icon(Icons.delete_outline, color: Colors.white),
                                label: const Text('حذف فایل صوتی', style: TextStyle(color: Colors.white)),
                              ),
                            ],
                          ),
                        ),
                    ],
                    const SizedBox(height: 18),
                    Center(
                      child: DaroGradientButton(
                        width: buttonWidth,
                        text: _showDetails ? 'ارسال درخواست' : 'ثبت درخواست',
                        loading: _submitting,
                        onPressed: widget.canRequestSpecial ? _submitQuickRequest : null,
                      ),
                    ),
                    if (widget.showLoginButton) ...[
                      const SizedBox(height: 12),
                      ElevatedButton.icon(
                        onPressed: widget.onLoginTap,
                        icon: const Icon(Icons.login),
                        label: const Text('ورود / ثبت‌نام'),
                      ),
                    ],
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 28, bottom: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _featureItem(Icons.verified_user_outlined, 'امنیت'),
                      _featureItem(Icons.store_mall_directory_outlined, 'داروخانه مجاز'),
                      _featureItem(Icons.local_shipping_outlined, 'تحویل سریع'),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class AdminPanel extends StatelessWidget {
  const AdminPanel({super.key, required this.api});

  final ApiClient api;

  @override
  Widget build(BuildContext context) {
    final content = ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'پنل مدیریت',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        const Text(
          'اعلان سفارش‌های جدید و پیام‌ها اینجا نمایش داده می‌شود.',
        ),
        const SizedBox(height: 12),
        NotificationsPreview(api: api, limit: 8),
        const SizedBox(height: 24),
      ],
    );
    return DaroPanel(child: content);
  }
}

class NotificationsPreview extends StatefulWidget {
  const NotificationsPreview({
    super.key,
    required this.api,
    this.limit = 5,
  });

  final ApiClient api;
  final int limit;

  @override
  State<NotificationsPreview> createState() => _NotificationsPreviewState();
}

class _NotificationsPreviewState extends State<NotificationsPreview> {
  bool _loading = false;
  List<AppNotification> _items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final items = await widget.api.fetchNotifications(unreadOnly: true, limit: widget.limit);
      if (!mounted) return;
      setState(() => _items = items);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('دریافت اعلان‌ها ناموفق بود')),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _markAllRead() async {
    try {
      await widget.api.markNotificationsRead(all: true);
      await _load();
      BadgeRefreshBus.request();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('عملیات ناموفق بود')),
        );
      }
    }
  }

  Future<void> _markOneRead(AppNotification item) async {
    try {
      await widget.api.markNotificationsRead(ids: [item.id]);
      await _load();
      BadgeRefreshBus.request();
    } catch (_) {
      // ignore
    }
  }

  IconData _iconForType(String type) {
    switch (type) {
      case 'order_created':
      case 'special_request_created':
        return Icons.receipt_long;
      case 'order_status':
        return Icons.update;
      default:
        return Icons.notifications_none;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'اعلان‌ها',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
                IconButton(
                  onPressed: _loading ? null : _load,
                  icon: const Icon(Icons.refresh),
                  tooltip: 'به‌روزرسانی',
                ),
                if (_items.isNotEmpty)
                  TextButton(
                    onPressed: _loading ? null : _markAllRead,
                    child: const Text('خوانده شد'),
                  ),
              ],
            ),
            if (_loading) const LinearProgressIndicator(minHeight: 2),
            if (!_loading && _items.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: Text('اعلان جدیدی ندارید.'),
              ),
            if (_items.isNotEmpty)
              ..._items.map(
                (n) => Column(
                  children: [
                    ListTile(
                      dense: true,
                      leading: Icon(_iconForType(n.type), color: Colors.teal),
                      title: Text(n.title.isNotEmpty ? n.title : 'اعلان'),
                      subtitle: n.body.isNotEmpty ? Text(n.body) : null,
                      onTap: () => _markOneRead(n),
                    ),
                    if (n != _items.last) const Divider(height: 1),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key, required this.api});

  final ApiClient api;

  @override
  State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  bool _loading = false;
  bool _marking = false;
  List<AppNotification> _items = [];
  Timer? _pollTimer;

  @override
  void initState() {
    super.initState();
    _load();
    _pollTimer = Timer.periodic(const Duration(seconds: 20), (_) => _load(silent: true));
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  Future<void> _load({bool silent = false}) async {
    if (_loading || _marking) return;
    if (!silent) {
      setState(() => _loading = true);
    } else {
      _loading = true;
    }
    try {
      final items = await widget.api.fetchNotifications(unreadOnly: false, limit: 100);
      if (!mounted) return;
      setState(() {
        _items = items;
        _loading = false;
      });
    } catch (_) {
      if (mounted && !silent) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('دریافت اعلان‌ها ناموفق بود')),
        );
      }
      if (mounted) {
        setState(() => _loading = false);
      } else {
        _loading = false;
      }
    } finally {
      if (!mounted) return;
      if (_loading) setState(() => _loading = false);
    }
  }

  Future<void> _markAllRead() async {
    setState(() => _marking = true);
    try {
      await widget.api.markNotificationsRead(all: true);
      await _load();
      BadgeRefreshBus.request();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('عملیات ناموفق بود')),
        );
      }
    } finally {
      if (mounted) setState(() => _marking = false);
    }
  }

  Future<void> _markOneRead(AppNotification item) async {
    if (item.isRead) return;
    try {
      await widget.api.markNotificationsRead(ids: [item.id]);
      await _load();
      BadgeRefreshBus.request();
    } catch (_) {
      // ignore
    }
  }

  IconData _iconForType(String type) {
    switch (type) {
      case 'order_created':
      case 'special_request_created':
        return Icons.receipt_long;
      case 'order_status':
        return Icons.update;
      default:
        return Icons.notifications_none;
    }
  }

  @override
  Widget build(BuildContext context) {
    final content = RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'اعلان‌ها',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ),
              IconButton(
                onPressed: (_loading || _marking) ? null : _load,
                icon: const Icon(Icons.refresh),
                tooltip: 'به‌روزرسانی',
              ),
              if (_items.isNotEmpty)
                TextButton(
                  onPressed: (_loading || _marking) ? null : _markAllRead,
                  child: _marking ? const Text('...') : const Text('خوانده شد'),
                ),
            ],
          ),
          if (_loading) const LinearProgressIndicator(),
          if (!_loading && _items.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Text('اعلانی وجود ندارد.'),
            ),
          ..._items.map(
            (n) => Card(
              child: ListTile(
                leading: Icon(_iconForType(n.type), color: Colors.teal),
                title: Text(
                  n.title.isNotEmpty ? n.title : 'اعلان',
                  style: TextStyle(
                    fontWeight: n.isRead ? FontWeight.w500 : FontWeight.w800,
                  ),
                ),
                subtitle: n.body.isNotEmpty ? Text(n.body) : null,
                trailing: n.isRead ? null : const Icon(Icons.circle, size: 10, color: Colors.red),
                onTap: () => _markOneRead(n),
              ),
            ),
          ),
        ],
      ),
    );

    return DaroPanel(child: content);
  }
}

class OrdersPage extends StatefulWidget {
  const OrdersPage({
    super.key,
    required this.api,
    required this.title,
    this.isAdmin = false,
    this.usePanel = false,
  });

  final ApiClient api;
  final String title;
  final bool isAdmin;
  final bool usePanel;

  @override
  State<OrdersPage> createState() => _OrdersPageState();
}

class _OrdersPageState extends State<OrdersPage> {
  bool _loading = false;
  bool _updating = false;
  bool _exporting = false;
  List<Order> _orders = [];
  static const List<String> _statuses = ['در حال بررسی', 'یافت شد', 'ارسال شد', 'تکمیل', 'لغو'];
  final _drugCtrl = TextEditingController();
  final _trackingCtrl = TextEditingController();
  String? _statusFilter;
  DateTime? _startDateFilter;
  DateTime? _endDateFilter;
  Timer? _pollTimer;
  static const List<String> _orderNotificationTypes = [
    'order_created',
    'order_status',
    'special_request_created',
  ];

  String _displayCustomerName(Order order) {
    final name = order.customerName.trim();
    if (name.isNotEmpty) return name;
    return 'نامشخص';
  }

  String _twoDigits(int value) => value.toString().padLeft(2, '0');

  String _formatDateTime(DateTime dateTime) {
    final local = dateTime.toLocal();
    return '${local.year}-${_twoDigits(local.month)}-${_twoDigits(local.day)} '
        '${_twoDigits(local.hour)}:${_twoDigits(local.minute)}';
  }

  Color _statusColor(String status) {
    switch (status.trim()) {
      case 'در حال بررسی':
        return Colors.amber.shade700;
      case 'یافت شد':
        return Colors.blue.shade600;
      case 'ارسال شد':
        return Colors.indigo.shade400;
      case 'تکمیل':
        return Colors.green.shade600;
      case 'لغو':
        return Colors.red.shade600;
      default:
        assert(false, 'Unexpected order status: $status');
        return Colors.amber.shade700;
    }
  }

  Widget _detailRow({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: Colors.teal.shade700),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              '$label: $value',
              style: const TextStyle(height: 1.35),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _promptChangeStatus(Order order) async {
    final selected = await showModalBottomSheet<String>(
      context: context,
      builder: (sheetContext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'تغییر وضعیت سفارش',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 8),
                Text(
                  '${order.drugName} — ${_displayCustomerName(order)}',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 12),
                ..._statuses.map(
                  (status) => ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(status),
                    trailing:
                        status == order.status ? const Icon(Icons.check_circle, color: Colors.teal) : null,
                    onTap: _updating ? null : () => Navigator.of(sheetContext).pop(status),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );

    if (selected == null || selected == order.status) return;
    await _changeStatus(order, selected);
  }

  Widget _orderCard(Order order) {
    final customer = _displayCustomerName(order);
    final notes = order.notes.trim();
    final statusColor = _statusColor(order.status);
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Stack(
        children: [
          ExpansionTile(
            tilePadding: const EdgeInsets.only(left: 16, right: 24, top: 8, bottom: 8),
            childrenPadding: const EdgeInsets.fromLTRB(16, 0, 24, 16),
            title: Text(
              order.drugName,
              style: const TextStyle(fontWeight: FontWeight.w800),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            subtitle: Text(
              widget.isAdmin ? 'مشتری: $customer' : 'کد پیگیری: ${order.trackingCode}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            children: [
              Align(
                alignment: Alignment.centerRight,
                child: Padding(
                  padding: const EdgeInsets.only(top: 8, bottom: 8),
                  child: Text(
                    'تعداد: ${order.quantity}',
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
              ),
              _detailRow(
                icon: Icons.confirmation_number_outlined,
                label: 'کد پیگیری',
                value: order.trackingCode,
              ),
              _detailRow(
                icon: Icons.category_outlined,
                label: 'دسته‌بندی',
                value: order.category,
              ),
              _detailRow(
                icon: Icons.access_time,
                label: 'تاریخ ثبت',
                value: _formatDateTime(order.createdAt),
              ),
              _detailRow(
                icon: Icons.info_outline,
                label: 'وضعیت',
                value: order.status,
              ),
              _detailRow(
                icon: Icons.notes_outlined,
                label: 'توضیحات',
                value: notes.isEmpty ? 'بدون توضیحات' : notes,
              ),
              if (widget.isAdmin) ...[
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: (_loading || _updating) ? null : () => _promptChangeStatus(order),
                    icon: const Icon(Icons.sync_alt),
                    label: const Text('تغییر وضعیت'),
                  ),
                ),
              ],
            ],
          ),
          Positioned(
            top: 0,
            bottom: 0,
            right: 0,
            child: Container(
              width: 6,
              decoration: BoxDecoration(
                color: statusColor,
                borderRadius: const BorderRadius.horizontal(right: Radius.circular(12)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _load();
    _markOrderNotificationsRead();
    if (widget.isAdmin) {
      _pollTimer = Timer.periodic(const Duration(seconds: 12), (_) => _load(silent: true));
    }
  }

  Future<void> _markOrderNotificationsRead() async {
    try {
      await widget.api.markNotificationsRead(types: _orderNotificationTypes);
      BadgeRefreshBus.request();
    } catch (_) {
      // ignore
    }
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _drugCtrl.dispose();
    _trackingCtrl.dispose();
    super.dispose();
  }

  Future<void> _load({bool silent = false}) async {
    if (_loading || _exporting || _updating) return;
    if (!silent) {
      setState(() => _loading = true);
    } else {
      _loading = true;
    }
    try {
      final items = await widget.api.fetchOrders(
        drugName: widget.isAdmin ? _drugCtrl.text.trim() : null,
        tracking: widget.isAdmin ? _trackingCtrl.text.trim() : null,
        status: widget.isAdmin ? _statusFilter : null,
        startDate: widget.isAdmin ? _startDateFilter : null,
        endDate: widget.isAdmin ? _endDateFilter : null,
      );
      if (!mounted) return;
      setState(() {
        _orders = items;
        _loading = false;
      });
    } catch (_) {
      if (mounted) {
        if (!silent) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('دریافت سفارش‌ها ناموفق بود')),
          );
        }
      }
      if (mounted) {
        setState(() => _loading = false);
      } else {
        _loading = false;
      }
    } finally {
      if (!mounted) return;
      if (_loading) setState(() => _loading = false);
    }
  }

  Future<void> _pickDate({required bool isStart}) async {
    final base = isStart ? _startDateFilter : _endDateFilter;
    final initial = base ?? _startDateFilter ?? DateTime.now();
    final now = DateTime.now();
    final firstDate = isStart ? DateTime(2020) : (_startDateFilter ?? DateTime(2020));
    final lastDate = now.add(const Duration(days: 365));
    final safeInitial = initial.isBefore(firstDate)
        ? firstDate
        : (initial.isAfter(lastDate) ? lastDate : initial);
    final picked = await showDatePicker(
      context: context,
      initialDate: safeInitial,
      firstDate: firstDate,
      lastDate: lastDate,
    );
    if (picked != null) {
      setState(() {
        if (isStart) {
          _startDateFilter = picked;
          if (_endDateFilter != null && _endDateFilter!.isBefore(picked)) {
            _endDateFilter = null;
          }
        } else {
          _endDateFilter = picked;
        }
      });
    }
  }

  Future<void> _changeStatus(Order order, String status) async {
    setState(() => _updating = true);
    try {
      await widget.api.updateOrderStatus(orderId: order.id, status: status);
      setState(() {
        _orders = _orders
            .map((o) => o.id == order.id ? Order.fromJson({..._orderToJson(o), 'status': status}) : o)
            .toList();
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('وضعیت سفارش به "$status" تغییر کرد')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تغییر وضعیت ناموفق بود')),
        );
      }
    } finally {
      if (mounted) setState(() => _updating = false);
    }
  }

  Future<void> _exportCsv() async {
    setState(() => _exporting = true);
    try {
      final bytes = await widget.api.exportOrdersCsv(
        drugName: _drugCtrl.text.trim(),
        tracking: _trackingCtrl.text.trim(),
        status: _statusFilter,
        startDate: _startDateFilter,
        endDate: _endDateFilter,
      );
      if (kIsWeb) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('دریافت فایل در وب پشتیبانی نشده است')),
        );
      } else {
        final dir = await getTemporaryDirectory();
        final file = File('${dir.path}/orders_${DateTime.now().millisecondsSinceEpoch}.csv');
        await file.writeAsBytes(bytes, flush: true);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('فایل ذخیره شد: ${file.path}')),
          );
        }
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('دریافت خروجی ناموفق بود')),
        );
      }
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  Map<String, dynamic> _orderToJson(Order o) => {
        'id': o.id,
        'trackingCode': o.trackingCode,
        'drugName': o.drugName,
        'quantity': o.quantity,
        'customerName': o.customerName,
        'notes': o.notes,
        'createdAt': o.createdAt.toIso8601String(),
        'status': o.status,
        'userId': o.userId,
      };

  @override
  Widget build(BuildContext context) {
    final content = RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                widget.title,
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
            ],
          ),
          if (widget.isAdmin) ...[
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                SizedBox(
                  width: 180,
                  child: TextField(
                    controller: _drugCtrl,
                    decoration: const InputDecoration(
                      labelText: 'نام دارو',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  child: TextField(
                    controller: _trackingCtrl,
                    decoration: const InputDecoration(
                      labelText: 'شماره پیگیری',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                  ),
                ),
                DropdownButton<String>(
                  hint: const Text('وضعیت'),
                  value: _statusFilter,
                  items: [
                    const DropdownMenuItem<String>(value: null, child: Text('همه')),
                    ..._statuses
                        .map((s) => DropdownMenuItem<String>(
                              value: s,
                              child: Text(s),
                            ))
                        .toList(),
                  ],
                  onChanged: (value) {
                    setState(() => _statusFilter = value);
                  },
                ),
                OutlinedButton.icon(
                  onPressed: () => _pickDate(isStart: true),
                  icon: const Icon(Icons.calendar_today_outlined),
                  label: Text(
                    _startDateFilter == null
                        ? 'تاریخ شروع'
                        : _startDateFilter!.toIso8601String().split('T').first,
                  ),
                ),
                OutlinedButton.icon(
                  onPressed: () => _pickDate(isStart: false),
                  icon: const Icon(Icons.event),
                  label: Text(
                    _endDateFilter == null
                        ? 'تاریخ پایان'
                        : _endDateFilter!.toIso8601String().split('T').first,
                  ),
                ),
                ElevatedButton.icon(
                  onPressed: _loading ? null : _load,
                  icon: const Icon(Icons.search),
                  label: const Text('جستجو'),
                ),
                OutlinedButton.icon(
                  onPressed: (_loading || _exporting) ? null : _exportCsv,
                  icon: _exporting
                      ? const SizedBox(
                          height: 16,
                          width: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.download),
                  label: const Text('خروجی اکسل'),
                ),
              ],
            ),
          ],
          if (_loading) const LinearProgressIndicator(),
          if (_updating) const LinearProgressIndicator(),
          ..._orders.map(
            _orderCard,
          ),
          if (!_loading && _orders.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 20),
              child: Text('سفارشی یافت نشد.'),
            ),
        ],
      ),
    );

    if (!widget.usePanel) return content;
    return DaroPanel(child: content);
  }
}

class AdminOrdersPage extends StatelessWidget {
  const AdminOrdersPage({super.key, required this.api, this.usePanel = false});

  final ApiClient api;
  final bool usePanel;

  @override
  Widget build(BuildContext context) {
    return OrdersPage(api: api, title: 'سفارش‌های دریافت‌شده', isAdmin: true, usePanel: usePanel);
  }
}

class ChatThreadsPage extends StatefulWidget {
  const ChatThreadsPage({
    super.key,
    required this.api,
    required this.user,
    required this.isAdmin,
    this.usePanel = false,
  });

  final ApiClient api;
  final UserProfile user;
  final bool isAdmin;
  final bool usePanel;

  @override
  State<ChatThreadsPage> createState() => _ChatThreadsPageState();
}

class _ChatThreadsPageState extends State<ChatThreadsPage> {
  bool _loading = false;
  bool _creating = false;
  String? _error;
  List<ChatThread> _threads = [];
  ChatThread? _userThread;
  Timer? _pollTimer;

  String? _clientName(ChatThread thread) {
    final parts = [
      thread.clientFirstName?.trim(),
      thread.clientLastName?.trim(),
    ].whereType<String>().where((p) => p.isNotEmpty).toList();
    if (parts.isEmpty) return null;
    return parts.join(' ');
  }

  @override
  void initState() {
    super.initState();
    _loadThreads();
    _pollTimer = Timer.periodic(const Duration(seconds: 6), (_) => _loadThreads(silent: true));
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadThreads({bool silent = false}) async {
    if (_loading || _creating) return;
    if (!silent) {
      setState(() {
        _loading = true;
        _error = null;
      });
    } else {
      _loading = true;
    }
    try {
      final threads = await widget.api.fetchChatThreads();
      if (!mounted) return;
      setState(() {
        _threads = threads;
        if (!widget.isAdmin) {
          _userThread = threads.isNotEmpty ? threads.first : null;
        }
        _loading = false;
        if (!silent) _error = null;
      });
    } catch (err) {
      if (!mounted) return;
      if (!silent) {
        setState(() {
          _error = 'دریافت گفتگوها ناموفق بود';
          _loading = false;
        });
      } else {
        _loading = false;
      }
    } finally {
      if (!mounted) return;
      if (_loading) setState(() => _loading = false);
    }
  }

  String _errMsg(Object err, String fallback) {
    if (err is ApiException && err.message.isNotEmpty) return err.message;
    return fallback;
  }

  Future<void> _connectSupport() async {
    setState(() {
      _creating = true;
      _error = null;
    });
    try {
      ChatThread? thread;
      try {
        final threads = await widget.api.fetchChatThreads();
        if (threads.isNotEmpty) thread = threads.first;
      } catch (_) {
        // ignore and fallback to ensure
      }
      thread ??= await widget.api.ensureChatThread();
      if (!mounted) return;
      setState(() {
        _userThread = thread;
        _error = null;
      });
    } catch (err) {
      if (mounted) {
        setState(() => _error = _errMsg(err, 'باز کردن چت ناموفق بود'));
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(_errMsg(err, 'شروع گفتگو ناموفق بود'))),
        );
      }
    } finally {
      if (mounted) setState(() => _creating = false);
    }
  }

  void _openThread(ChatThread thread) {
    Navigator.of(context)
        .push(
          MaterialPageRoute(
            builder: (_) => ChatRoomPage(
              api: widget.api,
              thread: thread,
              user: widget.user,
              isAdmin: widget.isAdmin,
              onMessageSent: () => _loadThreads(silent: true),
            ),
          ),
        )
        .then((_) => _loadThreads());
  }

  @override
  Widget build(BuildContext context) {
    Widget body;
    if (!widget.isAdmin) {
      if (_userThread != null) {
        body = ChatRoomPage(
          api: widget.api,
          thread: _userThread!,
          user: widget.user,
          isAdmin: widget.isAdmin,
          embedded: true,
        );
      } else {
        body = DaroPanel(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'چت پشتیبانی',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                const Text('برای شروع گفتگو، دکمه زیر را بزنید.'),
                const SizedBox(height: 12),
                if (_loading) const LinearProgressIndicator(),
                ElevatedButton.icon(
                  onPressed: (_creating || _loading) ? null : _connectSupport,
                  icon: _creating
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.chat_bubble_outline),
                  label: Text(_creating ? 'در حال ایجاد...' : 'شروع گفتگو'),
                ),
                if (_error != null) ...[
                  const SizedBox(height: 8),
                  Text(_error!, style: const TextStyle(color: Colors.red)),
                ],
              ],
            ),
          ),
        );
      }
    } else {
      body = Column(
        children: [
          if (_loading) const LinearProgressIndicator(),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(_error!, style: const TextStyle(color: Colors.red)),
            ),
          Expanded(
            child: RefreshIndicator(
              onRefresh: _loadThreads,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Row(
                    children: [
                      Text(
                        widget.isAdmin ? 'گفتگوهای مشتریان' : 'چت با پشتیبانی',
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  ..._threads.map(
                    (thread) => Card(
                      child: ListTile(
                        onTap: () => _openThread(thread),
                        leading: widget.isAdmin ? const Icon(Icons.person_outline) : null,
                        title: Text(
                          widget.isAdmin ? (_clientName(thread) ?? thread.clientId) : 'گفتگو',
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                        subtitle: widget.isAdmin
                            ? null
                            : Text(
                                thread.lastMessage?.body ?? 'پیامی وجود ندارد',
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                        trailing: widget.isAdmin
                            ? (thread.unreadCount > 0
                                ? Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: Colors.red,
                                      borderRadius: BorderRadius.circular(999),
                                    ),
                                    child: Text(
                                      '${thread.unreadCount}',
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w800,
                                        fontSize: 12,
                                      ),
                                    ),
                                  )
                                : null)
                            : Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(thread.status == 'open' ? 'باز' : 'بسته'),
                                  if (thread.updatedAt != null)
                                    Text(
                                      '${thread.updatedAt}',
                                      style: const TextStyle(fontSize: 11),
                                    ),
                                ],
                              ),
                      ),
                    ),
                  ),
                  if (!_loading && _threads.isEmpty && widget.isAdmin)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Text('گفتگویی یافت نشد'),
                    ),
                ],
              ),
            ),
          ),
        ],
      );
    }
    if (!widget.usePanel) return body;
    return DaroPanel(child: body);
  }
}

class ChatRoomPage extends StatefulWidget {
  const ChatRoomPage({
    super.key,
    required this.api,
    required this.thread,
    required this.user,
    required this.isAdmin,
    this.embedded = false,
    this.onMessageSent,
  });

  final ApiClient api;
  final ChatThread thread;
  final UserProfile user;
  final bool isAdmin;
  final bool embedded;
  final VoidCallback? onMessageSent;

  @override
  State<ChatRoomPage> createState() => _ChatRoomPageState();
}

class _ChatRoomPageState extends State<ChatRoomPage> with SingleTickerProviderStateMixin {
  final TextEditingController _msgCtrl = TextEditingController();
  final AudioRecorder _audioRecorder = AudioRecorder();
  final AudioPlayer _audioPlayer = AudioPlayer();
  late final AnimationController _pulseController;
  Timer? _pollTimer;
  bool _pollingMessages = false;
  bool _sending = false;
  bool _loading = false;
  bool _recording = false;
  String? _playingMessageId;
  List<ChatMessage> _messages = [];

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
      lowerBound: 0.0,
      upperBound: 1.0,
    );
    _loadMessages();
    _pollTimer = Timer.periodic(const Duration(seconds: 4), (_) => _pollMessages());
    _audioPlayer.onPlayerComplete.listen((_) {
      if (mounted) setState(() => _playingMessageId = null);
    });
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _msgCtrl.dispose();
    if (_recording) {
      _audioRecorder.stop();
    }
    _audioRecorder.dispose();
    _audioPlayer.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _loadMessages() async {
    setState(() => _loading = true);
    try {
      final msgs = await widget.api.fetchChatMessages(widget.thread.id);
      setState(() => _messages = msgs);
      BadgeRefreshBus.request();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('دریافت پیام‌ها ناموفق بود')),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _pollMessages() async {
    if (_pollingMessages) return;
    _pollingMessages = true;
    try {
      final msgs = await widget.api.fetchChatMessages(widget.thread.id);
      if (!mounted) return;
      final currentLast = _messages.isNotEmpty ? _messages.last.id : null;
      final nextLast = msgs.isNotEmpty ? msgs.last.id : null;
      if (msgs.length != _messages.length || nextLast != currentLast) {
        setState(() => _messages = msgs);
        BadgeRefreshBus.request();
      }
    } catch (_) {
      // ignore polling errors
    } finally {
      _pollingMessages = false;
    }
  }

  Future<void> _send() async {
    final text = _msgCtrl.text.trim();
    if (text.isEmpty) return;
    setState(() => _sending = true);
    try {
      final msg = await widget.api.sendChatMessage(threadId: widget.thread.id, body: text);
      _msgCtrl.clear();
      setState(() => _messages = [..._messages, msg]);
      widget.onMessageSent?.call();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('ارسال پیام ناموفق بود')),
        );
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _startRecording() async {
    try {
      if (!await _audioRecorder.hasPermission()) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('دسترسی به میکروفون داده نشد')),
        );
        return;
      }
      final outputPath =
          '${Directory.systemTemp.path}/chat_${DateTime.now().millisecondsSinceEpoch}.m4a';
      await _audioRecorder.start(
        const RecordConfig(
          encoder: AudioEncoder.aacLc,
          bitRate: 128000,
          sampleRate: 44100,
        ),
        path: outputPath,
      );
      setState(() => _recording = true);
      _pulseController.repeat(reverse: true);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('ضبط صدا ممکن نشد')),
        );
      }
    }
  }

  Future<void> _stopRecordingAndSend() async {
    if (!_recording) return;
    final path = await _audioRecorder.stop();
    _pulseController.stop();
    _pulseController.value = 0;
    setState(() => _recording = false);
    if (path != null) {
      await _sendAudio(path);
    }
  }

  Future<void> _sendAudio(String path) async {
    setState(() => _sending = true);
    try {
      final bytes = await File(path).readAsBytes();
      final b64 = base64Encode(bytes);
      final msg = await widget.api.sendChatMessage(
        threadId: widget.thread.id,
        body: 'پیام صوتی',
        audioBase64: b64,
      );
      setState(() => _messages = [..._messages, msg]);
      widget.onMessageSent?.call();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('ارسال پیام صوتی ناموفق بود')),
        );
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  String _resolveAttachmentUrl(String raw) {
    if (raw.isEmpty) return raw;
    if (raw.startsWith('http://') || raw.startsWith('https://')) return raw;
    final base = widget.api.baseUrl.endsWith('/')
        ? widget.api.baseUrl.substring(0, widget.api.baseUrl.length - 1)
        : widget.api.baseUrl;
    final path = raw.startsWith('/') ? raw : '/$raw';
    return '$base$path';
  }

  Future<void> _togglePlay(ChatMessage msg) async {
    if (msg.attachmentUrl.isEmpty) return;
    if (_playingMessageId == msg.id) {
      await _audioPlayer.stop();
      if (mounted) setState(() => _playingMessageId = null);
      return;
    }
    final url = _resolveAttachmentUrl(msg.attachmentUrl);
    setState(() => _playingMessageId = msg.id);
    try {
      await _audioPlayer.stop();
      await _audioPlayer.play(UrlSource(url));
    } catch (_) {
      if (mounted) {
        setState(() => _playingMessageId = null);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('پخش صدا ناموفق بود')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final myId = widget.user.id;
    final content = Column(
      children: [
        if (widget.embedded)
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
            child: Row(
              children: [
                Text(widget.isAdmin ? 'چت با مشتری' : 'چت پشتیبانی',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        if (_loading) const LinearProgressIndicator(),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: _messages.length,
              itemBuilder: (context, index) {
                final msg = _messages[index];
                final isMine = msg.senderId == myId;
                return Align(
                  alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.all(10),
                    constraints: const BoxConstraints(maxWidth: 280),
                    decoration: BoxDecoration(
                      color: isMine ? Colors.teal.shade100 : Colors.grey.shade200,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: msg.attachmentUrl.isNotEmpty
                        ? Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                padding: EdgeInsets.zero,
                                constraints: const BoxConstraints(),
                                icon: Icon(
                                  _playingMessageId == msg.id ? Icons.stop_circle : Icons.play_arrow,
                                  color: Colors.teal.shade700,
                                ),
                                onPressed: () => _togglePlay(msg),
                              ),
                              const SizedBox(width: 8),
                              Flexible(
                                child: Text(
                                  msg.body.isNotEmpty ? msg.body : 'پیام صوتی',
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          )
                        : Text(msg.body),
                  ),
                );
              },
            ),
          ),
        const Divider(height: 1),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _msgCtrl,
                  decoration: const InputDecoration(
                    hintText: 'پیام خود را بنویسید...',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  minLines: 1,
                  maxLines: 3,
                ),
              ),
              const SizedBox(width: 8),
              if (_recording)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.fiber_manual_record, color: Colors.red.shade600, size: 14),
                      const SizedBox(width: 4),
                      const Text('در حال ضبط', style: TextStyle(fontSize: 12)),
                    ],
                  ),
                ),
              AnimatedBuilder(
                animation: _pulseController,
                builder: (context, child) {
                  final scale = _recording ? 1.0 + (_pulseController.value * 0.12) : 1.0;
                  return Transform.scale(
                    scale: scale,
                    child: child,
                  );
                },
                child: GestureDetector(
                  onLongPressStart: (_) {
                    if (_sending) return;
                    _startRecording();
                  },
                  onLongPressEnd: (_) {
                    if (_sending) return;
                    _stopRecordingAndSend();
                  },
                  onTap: () {
                    if (_sending) return;
                    _recording ? _stopRecordingAndSend() : _startRecording();
                  },
                  child: Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: _recording
                            ? [Colors.red.shade400, Colors.red.shade700]
                            : [Colors.teal.shade400, Colors.teal.shade700],
                      ),
                      boxShadow: [
                        if (_recording)
                          BoxShadow(
                            color: Colors.red.withOpacity(0.4),
                            blurRadius: 16,
                            spreadRadius: 2,
                          ),
                      ],
                    ),
                    child: Icon(
                      _recording ? Icons.mic : Icons.mic_none,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton(
                onPressed: _sending ? null : _send,
                icon: _sending
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.send),
                color: Colors.teal,
              ),
            ],
          ),
        ),
      ],
    );

    if (widget.embedded) return content;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isAdmin ? 'چت با مشتری' : 'چت پشتیبانی'),
      ),
      body: content,
    );
  }
}

class OrderSheet extends StatefulWidget {
  const OrderSheet({super.key, required this.drug, required this.onSubmit});

  final Drug drug;
  final Future<void> Function(CreateOrderRequest request) onSubmit;

  @override
  State<OrderSheet> createState() => _OrderSheetState();
}

class _OrderSheetState extends State<OrderSheet> {
  static const List<String> _categories = ['دارو', 'مکمل', 'تجهیزات', 'لوازم مصرفی'];

  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameCtrl = TextEditingController();
  final TextEditingController _qtyCtrl = TextEditingController(text: '1');
  final TextEditingController _noteCtrl = TextEditingController();
  bool _submitting = false;
  String _category = _categories.first;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
        left: 16,
        right: 16,
        top: 8,
      ),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'سفارش ${widget.drug.name}',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _nameCtrl,
              decoration: const InputDecoration(
                labelText: 'نام شما',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 8),
            TextFormField(
              controller: _qtyCtrl,
              decoration: const InputDecoration(
                labelText: 'تعداد',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
              validator: (value) {
                final qty = int.tryParse(value ?? '');
                if (qty == null || qty <= 0) return 'تعداد نامعتبر است';
                return null;
              },
            ),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: _category,
              decoration: const InputDecoration(
                labelText: 'دسته‌بندی',
                border: OutlineInputBorder(),
              ),
              items: _categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
              onChanged: _submitting ? null : (value) => setState(() => _category = value ?? _categories.first),
            ),
            const SizedBox(height: 8),
            TextFormField(
              controller: _noteCtrl,
              decoration: const InputDecoration(
                labelText: 'توضیحات',
                border: OutlineInputBorder(),
              ),
              maxLines: 2,
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _submitting
                  ? null
                  : () async {
                      if (!_formKey.currentState!.validate()) return;
                      setState(() => _submitting = true);
                      await widget.onSubmit(
                        CreateOrderRequest(
                          drugId: widget.drug.id,
                          quantity: int.tryParse(_qtyCtrl.text) ?? 1,
                          category: _category,
                          customerName: _nameCtrl.text.trim(),
                          notes: _noteCtrl.text.trim(),
                        ),
                      );
                      if (mounted) {
                        setState(() => _submitting = false);
                      }
                    },
              child: _submitting
                  ? const SizedBox(
                      height: 18,
                      width: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Text('ثبت سفارش'),
            ),
          ],
        ),
      ),
    );
  }
}

class SpecialRequestSheet extends StatefulWidget {
  const SpecialRequestSheet({super.key, required this.onSubmit});

  final Future<void> Function(CreateSpecialRequest request) onSubmit;

  @override
  State<SpecialRequestSheet> createState() => _SpecialRequestSheetState();
}

class _SpecialRequestSheetState extends State<SpecialRequestSheet> {
  static const List<String> _categories = ['دارو', 'مکمل', 'تجهیزات', 'لوازم مصرفی', 'درخواست ویژه'];

  final _formKey = GlobalKey<FormState>();
  final TextEditingController _drugNameCtrl = TextEditingController();
  final TextEditingController _noteCtrl = TextEditingController();
  bool _submitting = false;
  final ImagePicker _picker = ImagePicker();
  String? _imageDataUrl;
  String? _audioBase64;
  final AudioRecorder _voiceRecorder = AudioRecorder();
  bool _recordingAudio = false;
  String? _category;
  // Keep client-side limit lower than server to fail fast before upload.
  static const int _maxImageBytes = 8 * 1024 * 1024; // 8 MB

  @override
  void dispose() {
    _drugNameCtrl.dispose();
    _noteCtrl.dispose();
    _imageDataUrl = null;
    _audioBase64 = null;
    if (_recordingAudio) {
      _voiceRecorder.stop();
    }
    _voiceRecorder.dispose();
    super.dispose();
  }

  Future<void> _pickImage({required bool fromCamera}) async {
    try {
      final XFile? file = await _picker.pickImage(
        source: fromCamera ? ImageSource.camera : ImageSource.gallery,
        imageQuality: 80,
      );
      if (file == null) return;
      final bytes = await file.readAsBytes();
      if (bytes.length > _maxImageBytes) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('حجم تصویر بیش از حد مجاز است (حداکثر ۸ مگابایت).')),
          );
        }
        return;
      }
      final mime = lookupMimeType(file.name) ?? 'image/jpeg';
      setState(() {
        _imageDataUrl = 'data:$mime;base64,${base64Encode(bytes)}';
      });
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('انتخاب تصویر ناموفق بود')),
      );
    }
  }

  Future<void> _startVoiceRecording() async {
    try {
      if (!await _voiceRecorder.hasPermission()) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('دسترسی به میکروفون داده نشد')),
        );
        return;
      }
      final dir = await getTemporaryDirectory();
      final path = '${dir.path}/special_voice_${DateTime.now().millisecondsSinceEpoch}.m4a';
      await _voiceRecorder.start(
        const RecordConfig(
          encoder: AudioEncoder.aacLc,
          bitRate: 128000,
          sampleRate: 44100,
        ),
        path: path,
      );
      setState(() {
        _recordingAudio = true;
        _audioBase64 = null;
      });
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('شروع ضبط صدا ممکن نشد')),
      );
    }
  }

  Future<void> _stopVoiceRecording() async {
    try {
      final path = await _voiceRecorder.stop();
      setState(() => _recordingAudio = false);
      if (path != null) {
        final bytes = await File(path).readAsBytes();
        setState(() => _audioBase64 = base64Encode(bytes));
      }
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('ذخیره صدای ضبط‌شده ممکن نشد')),
      );
    }
  }

  void _clearAudio() {
    setState(() => _audioBase64 = null);
  }


  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
        left: 16,
        right: 16,
        top: 8,
      ),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'ثبت داروی جدید',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _drugNameCtrl,
              decoration: const InputDecoration(
                labelText: 'نام دارو',
                border: OutlineInputBorder(),
              ),
              validator: (value) {
                if (value == null || value.trim().isEmpty) {
                  return 'نام دارو را وارد کنید';
                }
                return null;
              },
            ),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              decoration: const InputDecoration(
                labelText: 'نوع درخواست',
                border: OutlineInputBorder(),
              ),
              value: _category,
              items: _categories
                  .map(
                    (c) => DropdownMenuItem<String>(
                      value: c,
                      child: Text(c),
                    ),
                  )
                  .toList(),
              onChanged: (value) => setState(() => _category = value),
              validator: (value) => value == null ? 'یک گزینه را انتخاب کنید' : null,
            ),
            const SizedBox(height: 8),
            TextFormField(
              controller: _noteCtrl,
              decoration: const InputDecoration(
                labelText: 'توضیحات تکمیلی',
                border: OutlineInputBorder(),
              ),
              maxLines: 2,
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.center,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 260),
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      minimumSize: const Size(0, 48),
                    ),
                    onPressed: () => _pickImage(fromCamera: true),
                    icon: Icon(
                      Icons.camera_alt_rounded,
                      color: Colors.teal.shade700,
                    ),
                    label: const Text(
                      'گرفتن عکس نسخه',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            if (_imageDataUrl != null)
              Column(
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        color: Colors.grey.shade100,
                        padding: const EdgeInsets.all(8),
                        child: Image.memory(
                          base64Decode(_imageDataUrl!.split(',').last),
                          height: 180,
                          width: 260,
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      OutlinedButton.icon(
                        onPressed: () => setState(() => _imageDataUrl = null),
                        icon: const Icon(Icons.close),
                        label: const Text('حذف تصویر'),
                      ),
                      const SizedBox(width: 8),
                      OutlinedButton.icon(
                        onPressed: () => _pickImage(fromCamera: true),
                        icon: const Icon(Icons.camera_alt_outlined),
                        label: const Text('گرفتن عکس دیگر'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                ],
              ),
            Align(
              alignment: Alignment.center,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 260),
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    minimumSize: const Size(0, 48),
                  ),
                  onPressed: _recordingAudio ? _stopVoiceRecording : _startVoiceRecording,
                  icon: Icon(
                    _recordingAudio ? Icons.stop_circle_outlined : Icons.mic_none,
                    color: _recordingAudio ? Colors.red : Colors.teal.shade700,
                  ),
                  label: Text(_recordingAudio ? 'پایان ضبط و ذخیره' : 'ضبط و ارسال صدا'),
                ),
              ),
            ),
            if (_audioBase64 != null)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Column(
                  children: [
                    const Text('صدای شما آماده ارسال است'),
                    TextButton.icon(
                      onPressed: _clearAudio,
                      icon: const Icon(Icons.delete_outline),
                      label: const Text('حذف فایل صوتی'),
                    ),
                  ],
                ),
              ),
            ElevatedButton(
              onPressed: _submitting
                  ? null
                  : () async {
                      if (!_formKey.currentState!.validate()) return;
                      setState(() => _submitting = true);
                      await widget.onSubmit(
                        CreateSpecialRequest(
                          drugName: _drugNameCtrl.text.trim(),
                          category: _category ?? '',
                          description: '',
                          customerName: '',
                          notes: _noteCtrl.text.trim(),
                          imageUrl: _imageDataUrl ?? '',
                          audioUrl: _audioBase64 ?? '',
                        ),
                      );
                      if (mounted) {
                        setState(() => _submitting = false);
                      }
                    },
              child: _submitting
                  ? const SizedBox(
                      height: 18,
                      width: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Text('ارسال'),
            ),
          ],
        ),
      ),
    );
  }
}

// --- API layer & models ---

class ApiClient {
  ApiClient({
    String? baseUrl,
    http.Client? client,
  })  : baseUrl = baseUrl ?? _defaultBaseUrl(),
        _client = client ?? http.Client();

  final String baseUrl;
  final http.Client _client;
  final SessionStore _sessionStore = const SessionStore();
  String? _token;
  String? _refreshToken;

  static String _defaultBaseUrl() {
    final env = const String.fromEnvironment('API_URL');
    final raw = env.isNotEmpty ? env : 'https://darocheck.liara.run';
    var value = raw.trim();
    while (value.endsWith('/')) {
      value = value.substring(0, value.length - 1);
    }
    if (!value.contains('://')) {
      final isLocal = value.startsWith('localhost') ||
          value.startsWith('127.') ||
          value.startsWith('10.') ||
          value.startsWith('192.168.') ||
          value.startsWith('172.16.') ||
          value.startsWith('172.17.') ||
          value.startsWith('172.18.') ||
          value.startsWith('172.19.') ||
          value.startsWith('172.2') ||
          value.startsWith('172.30.') ||
          value.startsWith('172.31.');
      value = '${isLocal ? 'http' : 'https'}://$value';
    }

    // Android emulator cannot reach host machine via localhost.
    // Use 10.0.2.2 (host loopback) when API_URL points to localhost/127.0.0.1.
    final parsed = Uri.tryParse(value);
    if (parsed != null &&
        !kIsWeb &&
        Platform.isAndroid &&
        (parsed.host == 'localhost' || parsed.host == '127.0.0.1')) {
      value = parsed.replace(host: '10.0.2.2').toString();
    }

    // Avoid CORS-breaking redirects (Liara redirects http->https without CORS headers).
    if (value.startsWith('http://darocheck.liara.run')) {
      value = value.replaceFirst('http://', 'https://');
    }
    return value;
  }

  Uri _uri(String path, [Map<String, String>? query]) =>
      Uri.parse('$baseUrl$path').replace(queryParameters: query);

  Future<UserProfile> login({
    required String phone,
    required String password,
  }) async {
    final response = await _client.post(
      _uri('/api/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'phone': phone, 'password': password, 'username': phone}),
    );
    _ensureOk(response);
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final user = UserProfile.fromJson(data['user'] as Map<String, dynamic>);
    final token = data['token'] as String?;
    final refreshToken = data['refreshToken'] as String?;
    setAuthToken(token);
    setRefreshToken(refreshToken);
    await _persistSession(user);
    return user;
  }

  Future<RegisterResult> register({
    required String firstName,
    required String lastName,
    required String phone,
    required String password,
    String role = 'user',
  }) async {
    final response = await _client.post(
      _uri('/api/auth/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'firstName': firstName,
        'lastName': lastName,
        'phone': phone,
        'password': password,
        'role': role,
      }),
    );
    _ensureOk(response, allow201: true);
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    if (data['pendingVerification'] == true) {
      return RegisterResult(
        username: data['username'] as String?,
        devCode: data['code'] as String?,
        pendingVerification: true,
      );
    }
    final user = UserProfile.fromJson(data['user'] as Map<String, dynamic>);
    setAuthToken(data['token'] as String?);
    setRefreshToken(data['refreshToken'] as String?);
    await _persistSession(user);
    return RegisterResult(user: user);
  }

  Future<UserProfile> verifyCode({
    required String username,
    required String code,
  }) async {
    final response = await _client.post(
      _uri('/api/auth/verify'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'username': username, 'code': code}),
    );
    _ensureOk(response);
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final user = UserProfile.fromJson(data['user'] as Map<String, dynamic>);
    final token = data['token'] as String?;
    final refreshToken = data['refreshToken'] as String?;
    setAuthToken(token);
    setRefreshToken(refreshToken);
    await _persistSession(user);
    return user;
  }

  Future<DevCodeResult> requestLoginCode({required String phone}) async {
    final response = await _client.post(
      _uri('/api/auth/login-code'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'phone': phone}),
    );
    _ensureOk(response);
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return DevCodeResult(devCode: data['code'] as String?);
  }

  Future<UserProfile> loginWithCode({required String phone, required String code}) async {
    final response = await _client.post(
      _uri('/api/auth/login-with-code'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'phone': phone, 'code': code}),
    );
    _ensureOk(response);
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final user = UserProfile.fromJson(data['user'] as Map<String, dynamic>);
    final token = data['token'] as String?;
    final refreshToken = data['refreshToken'] as String?;
    setAuthToken(token);
    setRefreshToken(refreshToken);
    await _persistSession(user);
    return user;
  }

  Future<List<Drug>> fetchDrugs({String? query}) async {
    final response = await _client.get(
      _uri('/api/drugs', query?.isNotEmpty == true ? {'q': query!} : null),
    );
    _ensureOk(response);
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final list = (data['data'] as List).cast<Map<String, dynamic>>();
    return list.map(Drug.fromJson).toList();
  }

  Future<Order> createOrder(CreateOrderRequest request) async {
    final response = await _authorizedPost(
      '/api/orders',
      body: request.toJson(),
      allow201: true,
    );
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return Order.fromJson(data['data'] as Map<String, dynamic>);
  }

  Future<List<Order>> fetchOrders({
    String? drugName,
    String? tracking,
    String? status,
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    final query = <String, String>{};
    if (drugName != null && drugName.trim().isNotEmpty) query['drugName'] = drugName.trim();
    if (tracking != null && tracking.trim().isNotEmpty) query['tracking'] = tracking.trim();
    if (status != null && status.trim().isNotEmpty) query['status'] = status.trim();
    if (startDate != null) query['startDate'] = startDate.toIso8601String().split('T').first;
    if (endDate != null) query['endDate'] = endDate.toIso8601String().split('T').first;

    final response = await _authorizedGet('/api/orders', query: query.isEmpty ? null : query);
    _ensureOk(response);
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final list = (data['data'] as List).cast<Map<String, dynamic>>();
    return list.map(Order.fromJson).toList();
  }

  Future<int> fetchUnreadNotificationCount() async {
    final response = await _authorizedGet('/api/notifications/unread-count');
    _ensureOk(response);
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return (data['count'] ?? 0) as int;
  }

  Future<List<AppNotification>> fetchNotifications({bool unreadOnly = false, int limit = 30}) async {
    final response = await _authorizedGet(
      '/api/notifications',
      query: {
        'unreadOnly': unreadOnly ? 'true' : 'false',
        'limit': limit.toString(),
      },
    );
    _ensureOk(response);
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final list = (data['data'] as List).cast<Map<String, dynamic>>();
    return list.map(AppNotification.fromJson).toList();
  }

  Future<void> markNotificationsRead({List<String>? ids, List<String>? types, bool all = false}) async {
    await _authorizedPost(
      '/api/notifications/mark-read',
      body: {
        if (all) 'all': true,
        if (!all && ids != null) 'ids': ids,
        if (!all && ids == null && types != null) 'types': types,
      },
    );
  }

  Future<int> fetchUnreadChatCount() async {
    final response = await _authorizedGet('/api/chat/unread-count');
    _ensureOk(response);
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return (data['count'] ?? 0) as int;
  }

  Future<AppBadges> fetchBadges() async {
    final response = await _authorizedGet('/api/badges');
    _ensureOk(response);
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return AppBadges.fromJson(data);
  }

  Future<void> registerPushToken({required String token, String platform = ''}) async {
    await _authorizedPost(
      '/api/push/register',
      body: {'token': token, 'platform': platform},
    );
  }

  Future<void> updateOrderStatus({
    required String orderId,
    required String status,
  }) async {
    await _authorizedPost(
      '/api/orders/$orderId/status',
      body: {'status': status},
    );
  }

  Future<Uint8List> exportOrdersCsv({
    String? drugName,
    String? tracking,
    String? status,
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    final query = <String, String>{};
    if (drugName != null && drugName.trim().isNotEmpty) query['drugName'] = drugName.trim();
    if (tracking != null && tracking.trim().isNotEmpty) query['tracking'] = tracking.trim();
    if (status != null && status.trim().isNotEmpty) query['status'] = status.trim();
    if (startDate != null) query['startDate'] = startDate.toIso8601String().split('T').first;
    if (endDate != null) query['endDate'] = endDate.toIso8601String().split('T').first;

    final response = await _authorizedGet('/api/orders/export', query: query.isEmpty ? null : query);
    _ensureOk(response);
    return response.bodyBytes;
  }

  Future<Drug> addDrug({
    required String name,
    String? description,
    int stock = 0,
  }) async {
    final response = await _authorizedPost(
      '/api/drugs',
      body: {
        'name': name,
        'description': description,
        'stock': stock,
      },
      allow201: true,
    );
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return Drug.fromJson(data['data'] as Map<String, dynamic>);
  }

  Future<Order> createSpecialRequest(
    CreateSpecialRequest request,
  ) async {
    final response = await _authorizedPost(
      '/api/special-requests',
      body: request.toJson(),
      allow201: true,
    );
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return Order.fromJson(data['data'] as Map<String, dynamic>);
  }

  Future<ChatThread> ensureChatThread() async {
    final response = await _authorizedPost(
      '/api/chat/threads',
      body: const {},
      allow201: true,
    );
    _ensureOk(response, allow201: true);
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return ChatThread.fromJson(data['data'] as Map<String, dynamic>);
  }

  Future<List<ChatThread>> fetchChatThreads() async {
    final response = await _authorizedGet('/api/chat/threads');
    _ensureOk(response);
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final list = (data['data'] as List).cast<Map<String, dynamic>>();
    return list.map(ChatThread.fromJson).toList();
  }

  Future<List<ChatMessage>> fetchChatMessages(String threadId) async {
    final response = await _authorizedGet('/api/chat/threads/$threadId/messages');
    _ensureOk(response);
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final list = (data['data'] as List).cast<Map<String, dynamic>>();
    return list.map(ChatMessage.fromJson).toList();
  }

  Future<ChatMessage> sendChatMessage({
    required String threadId,
    String body = '',
    String? audioBase64,
  }) async {
    final response = await _authorizedPost(
      '/api/chat/threads/$threadId/messages',
      body: {
        'body': body,
        if (audioBase64 != null) 'audioBase64': audioBase64,
      },
      allow201: true,
    );
    _ensureOk(response, allow201: true);
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return ChatMessage.fromJson(data['data'] as Map<String, dynamic>);
  }

  void _ensureOk(http.Response response, {bool allow201 = false}) {
    final ok = response.statusCode == 200 || (allow201 && response.statusCode == 201);
    if (!ok) {
      String message = 'API error ${response.statusCode}';
      try {
        final body = jsonDecode(response.body);
        if (body is Map && body['message'] is String) {
          message = body['message'] as String;
        }
      } catch (_) {
        // ignore parse errors
      }
      throw ApiException(message, response.statusCode);
    }
  }

  void setAuthToken(String? token) {
    _token = token;
  }

  void setRefreshToken(String? token) {
    _refreshToken = token;
  }

  Future<void> _persistSession(UserProfile user) async {
    final token = _token?.trim() ?? '';
    final refreshToken = _refreshToken?.trim() ?? '';
    if (token.isEmpty || refreshToken.isEmpty) return;
    await _sessionStore.save(
      refreshToken: refreshToken,
      token: token,
      user: user.toJson(),
    );
  }

  Future<UserProfile?> restoreSession() async {
    final stored = await _sessionStore.load();
    if (stored == null) return null;
    if (stored.token != null) setAuthToken(stored.token);
    setRefreshToken(stored.refreshToken);

    final storedUser = stored.user != null ? UserProfile.fromJson(stored.user!) : null;
    try {
      final refreshedUser = await _refreshAccessTokenAndUser();
      if (refreshedUser != null) return refreshedUser;
      // If refresh was rejected, we cleared the session.
      if (_refreshToken == null) return null;
      return storedUser;
    } catch (_) {
      // offline / transient: keep stored session
      return storedUser;
    }
  }

  Map<String, String> _authHeaders() {
    final headers = <String, String>{};
    if (_token != null && _token!.isNotEmpty) {
      headers['Authorization'] = 'Bearer $_token';
    }
    return headers;
  }

  Future<http.Response> _authorizedGet(
    String path, {
    Map<String, String>? query,
  }) async {
    if (_token == null || _token!.isEmpty) {
      if (_refreshToken != null && _refreshToken!.isNotEmpty) {
        final refreshed = await _refreshAccessToken();
        if (!refreshed) throw ApiException('Unauthorized', 401);
      } else {
        throw ApiException('Unauthorized', 401);
      }
    }
    http.Response response = await _client.get(_uri(path, query), headers: _authHeaders());
    if (response.statusCode == 401 && _refreshToken != null) {
      final refreshed = await _refreshAccessToken();
      if (refreshed) {
        response = await _client.get(_uri(path, query), headers: _authHeaders());
      }
    }
    return response;
  }

  Future<http.Response> _authorizedPost(
    String path, {
    required Map<String, dynamic> body,
    bool allow201 = false,
  }) async {
    if (_token == null || _token!.isEmpty) {
      if (_refreshToken != null && _refreshToken!.isNotEmpty) {
        await _refreshAccessToken();
      }
    }
    http.Response response = await _client.post(
      _uri(path),
      headers: _headersWithAuth(),
      body: jsonEncode(body),
    );
    if (response.statusCode == 401 && _refreshToken != null) {
      final refreshed = await _refreshAccessToken();
      if (refreshed) {
        response = await _client.post(
          _uri(path),
          headers: _headersWithAuth(),
          body: jsonEncode(body),
        );
      }
    }
    _ensureOk(response, allow201: allow201);
    return response;
  }

  Future<bool> _refreshAccessToken() async {
    final user = await _refreshAccessTokenAndUser();
    return user != null;
  }

  Future<UserProfile?> _refreshAccessTokenAndUser() async {
    if (_refreshToken == null || _refreshToken!.trim().isEmpty) return null;
    final response = await _client.post(
      _uri('/api/auth/refresh'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'refreshToken': _refreshToken}),
    );
    if (response.statusCode != 200) {
      _token = null;
      _refreshToken = null;
      await _sessionStore.clear();
      return null;
    }
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    setAuthToken(data['token'] as String?);
    setRefreshToken(data['refreshToken'] as String?);
    final user = data['user'] is Map ? UserProfile.fromJson(Map<String, dynamic>.from(data['user'] as Map)) : null;
    if (user != null) {
      await _persistSession(user);
    }
    return user;
  }

  Future<void> logout() async {
    if (_refreshToken != null) {
      await _client.post(
        _uri('/api/auth/logout'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'refreshToken': _refreshToken}),
      );
    }
    _token = null;
    _refreshToken = null;
    await _sessionStore.clear();
  }

  Map<String, String> _headersWithAuth() {
    final headers = <String, String>{'Content-Type': 'application/json'};
    if (_token != null && _token!.isNotEmpty) {
      headers['Authorization'] = 'Bearer ${_token!}';
    }
    return headers;
  }
}

class ApiException implements Exception {
  ApiException(this.message, this.statusCode);

  final String message;
  final int statusCode;

  @override
  String toString() => 'ApiException($statusCode): $message';
}

class UserProfile {
  const UserProfile({
    required this.id,
    required this.username,
    required this.firstName,
    required this.lastName,
    required this.phone,
    required this.phoneVerified,
    required this.role,
    required this.createdAt,
  });

  final String id;
  final String username;
  final String firstName;
  final String lastName;
  final String phone;
  final bool phoneVerified;
  final String role;
  final DateTime createdAt;

  factory UserProfile.fromJson(Map<String, dynamic> json) => UserProfile(
        id: json['id'] as String,
        username: json['username'] as String,
        firstName: (json['firstName'] ?? '') as String,
        lastName: (json['lastName'] ?? '') as String,
        phone: (json['phone'] ?? '') as String,
        phoneVerified: (json['phoneVerified'] ?? false) as bool,
        role: (json['role'] ?? 'user') as String,
        createdAt: DateTime.parse(json['createdAt'] as String),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'username': username,
        'firstName': firstName,
        'lastName': lastName,
        'phone': phone,
        'phoneVerified': phoneVerified,
        'role': role,
        'createdAt': createdAt.toIso8601String(),
      };
}

class RegisterResult {
  const RegisterResult({this.user, this.username, this.devCode, this.pendingVerification = false});

  final UserProfile? user;
  final String? username;
  final String? devCode;
  final bool pendingVerification;
}

class DevCodeResult {
  const DevCodeResult({this.devCode});

  final String? devCode;
}

class AppNotification {
  const AppNotification({
    required this.id,
    required this.type,
    required this.title,
    required this.body,
    required this.isRead,
    required this.createdAt,
    required this.data,
  });

  final String id;
  final String type;
  final String title;
  final String body;
  final bool isRead;
  final DateTime? createdAt;
  final Map<String, dynamic> data;

  factory AppNotification.fromJson(Map<String, dynamic> json) => AppNotification(
        id: json['id'] as String,
        type: (json['type'] ?? '') as String,
        title: (json['title'] ?? '') as String,
        body: (json['body'] ?? '') as String,
        isRead: (json['isRead'] ?? false) as bool,
        createdAt: json['createdAt'] != null ? DateTime.tryParse(json['createdAt'] as String) : null,
        data: (json['data'] is Map) ? Map<String, dynamic>.from(json['data'] as Map) : const {},
      );
}

class AppBadges {
  const AppBadges({
    required this.notifications,
    required this.orders,
    required this.chat,
    required this.total,
  });

  final int notifications;
  final int orders;
  final int chat;
  final int total;

  factory AppBadges.fromJson(Map<String, dynamic> json) => AppBadges(
        notifications: (json['notifications'] ?? 0) as int,
        orders: (json['orders'] ?? 0) as int,
        chat: (json['chat'] ?? 0) as int,
        total: (json['total'] ?? 0) as int,
      );
}

class Drug {
  Drug({
    required this.id,
    required this.name,
    required this.description,
    required this.stock,
  });

  final String id;
  final String name;
  final String description;
  final int stock;

  factory Drug.fromJson(Map<String, dynamic> json) => Drug(
        id: json['id'] as String,
        name: json['name'] as String,
        description: (json['description'] ?? '') as String,
        stock: (json['stock'] ?? 0) as int,
      );
}

class Order {
  Order({
    required this.id,
    required this.trackingCode,
    required this.drugName,
    required this.quantity,
    required this.customerName,
    required this.notes,
    required this.createdAt,
    required this.status,
    required this.category,
    this.userId,
    this.imageUrl = '',
    this.audioUrl = '',
  });

  final String id;
  final String trackingCode;
  final String drugName;
  final int quantity;
  final String? userId;
  final String status;
  final String category;
  final String customerName;
  final String notes;
  final String imageUrl;
  final String audioUrl;
  final DateTime createdAt;

  factory Order.fromJson(Map<String, dynamic> json) => Order(
        id: json['id'] as String,
        trackingCode: json['trackingCode'] as String,
        drugName: json['drugName'] as String,
        quantity: (json['quantity'] ?? 1) as int,
        userId: json['userId'] as String?,
        status: (json['status'] ?? 'در حال بررسی') as String,
        category: (json['category'] ?? 'دارو') as String,
        customerName: (json['customerName'] ?? '') as String,
        notes: (json['notes'] ?? '') as String,
        imageUrl: (json['imageUrl'] ?? '') as String,
        audioUrl: (json['audioUrl'] ?? '') as String,
        createdAt: json['createdAt'] != null ? DateTime.parse(json['createdAt'] as String) : DateTime.now(),
      );
}

class SpecialRequest {
  SpecialRequest({
    required this.id,
    required this.trackingCode,
    required this.drugName,
    required this.description,
    required this.customerName,
    required this.notes,
    required this.imageUrl,
    required this.audioUrl,
    required this.createdAt,
  });

  final String id;
  final String trackingCode;
  final String drugName;
  final String description;
  final String customerName;
  final String notes;
  final String imageUrl;
  final String audioUrl;
  final DateTime createdAt;

  factory SpecialRequest.fromJson(Map<String, dynamic> json) => SpecialRequest(
        id: json['id'] as String,
        trackingCode: json['trackingCode'] as String,
        drugName: json['drugName'] as String,
        description: (json['description'] ?? '') as String,
        customerName: (json['customerName'] ?? '') as String,
        notes: (json['notes'] ?? '') as String,
        imageUrl: (json['imageUrl'] ?? '') as String,
        audioUrl: (json['audioUrl'] ?? '') as String,
        createdAt: DateTime.parse(json['createdAt'] as String),
      );
}

class CreateOrderRequest {
  CreateOrderRequest({
    required this.drugId,
    required this.quantity,
    required this.category,
    required this.customerName,
    required this.notes,
  });

  final String drugId;
  final int quantity;
  final String category;
  final String customerName;
  final String notes;

  Map<String, dynamic> toJson() => {
        'drugId': drugId,
        'quantity': quantity,
        'category': category,
        'customerName': customerName,
        'notes': notes,
      };
}

class CreateSpecialRequest {
  CreateSpecialRequest({
    required this.drugName,
    required this.category,
    required this.description,
    required this.customerName,
    required this.notes,
    required this.imageUrl,
    required this.audioUrl,
  });

  final String drugName;
  final String category;
  final String description;
  final String customerName;
  final String notes;
  final String imageUrl;
  final String audioUrl;

  Map<String, dynamic> toJson() => {
        'drugName': drugName,
        'category': category,
        'description': description,
        'customerName': customerName,
        'notes': notes,
        'imageUrl': imageUrl,
        'audioUrl': audioUrl,
      };
}

class ChatThread {
  ChatThread({
    required this.id,
    required this.clientId,
    required this.adminId,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
    required this.unreadCount,
    this.lastMessage,
    this.clientFirstName,
    this.clientLastName,
  });

  final String id;
  final String clientId;
  final String? adminId;
  final String status;
  final int unreadCount;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final String? clientFirstName;
  final String? clientLastName;
  final ChatLastMessage? lastMessage;

  factory ChatThread.fromJson(Map<String, dynamic> json) => ChatThread(
        id: json['id'] as String,
        clientId: json['clientId'] as String,
        adminId: json['adminId'] as String?,
        status: (json['status'] ?? 'open') as String,
        unreadCount: (json['unreadCount'] ?? 0) as int,
        createdAt: json['createdAt'] != null ? DateTime.parse(json['createdAt'] as String) : null,
        updatedAt: json['updatedAt'] != null ? DateTime.parse(json['updatedAt'] as String) : null,
        clientFirstName: json['clientFirstName'] as String?,
        clientLastName: json['clientLastName'] as String?,
        lastMessage: json['lastMessage'] != null
            ? ChatLastMessage.fromJson(json['lastMessage'] as Map<String, dynamic>)
            : null,
      );
}

class ChatLastMessage {
  const ChatLastMessage({required this.body, this.createdAt});

  final String body;
  final DateTime? createdAt;

  factory ChatLastMessage.fromJson(Map<String, dynamic> json) => ChatLastMessage(
        body: json['body'] as String? ?? '',
        createdAt: json['createdAt'] != null ? DateTime.parse(json['createdAt'] as String) : null,
      );
}

class ChatMessage {
  ChatMessage({
    required this.id,
    required this.threadId,
    required this.senderId,
    required this.senderRole,
    required this.body,
    required this.attachmentUrl,
    required this.createdAt,
  });

  final String id;
  final String threadId;
  final String senderId;
  final String senderRole;
  final String body;
  final String attachmentUrl;
  final DateTime createdAt;

  factory ChatMessage.fromJson(Map<String, dynamic> json) => ChatMessage(
        id: json['id'] as String,
        threadId: json['threadId'] as String,
        senderId: json['senderId'] as String,
        senderRole: json['senderRole'] as String,
        body: json['body'] as String,
        attachmentUrl: json['attachmentUrl'] as String? ?? '',
        createdAt: DateTime.parse(json['createdAt'] as String),
      );
}
