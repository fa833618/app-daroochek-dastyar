import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter/services.dart';

typedef PushTokenRegistrar = Future<void> Function({required String token, required String platform});

class PushManager {
  PushManager._();

  static final PushManager instance = PushManager._();

  static const MethodChannel _badgeChannel = MethodChannel('com.example.darocheck/badge');
  final FlutterLocalNotificationsPlugin _localNotifications = FlutterLocalNotificationsPlugin();
  PushTokenRegistrar? _registrar;

  bool _ready = false;
  String? _lastToken;
  static const String _channelId = 'darocheck_default';
  static const String _channelName = 'Notifications';

  Future<void> init() async {
    if (kIsWeb) return;
    if (_ready) return;

    try {
      await Firebase.initializeApp();
    } catch (err) {
      debugPrint('PushManager: Firebase init failed: $err');
      return;
    }

    try {
      const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
      const iosSettings = DarwinInitializationSettings();
      const settings = InitializationSettings(android: androidSettings, iOS: iosSettings);
      await _localNotifications.initialize(settings);

      final androidPlugin = _localNotifications.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      await androidPlugin?.createNotificationChannel(
        const AndroidNotificationChannel(
          _channelId,
          _channelName,
          description: 'DaroCheck notifications',
          importance: Importance.high,
          playSound: true,
          enableVibration: true,
        ),
      );
    } catch (err) {
      debugPrint('PushManager: local notifications init failed: $err');
    }

    try {
      await FirebaseMessaging.instance.requestPermission();
    } catch (err) {
      debugPrint('PushManager: permission request failed: $err');
    }

    FirebaseMessaging.onMessage.listen(_handleForegroundMessage);
    FirebaseMessaging.instance.onTokenRefresh.listen((token) {
      _lastToken = token;
      _tryRegisterToken();
    });

    try {
      _lastToken = await FirebaseMessaging.instance.getToken();
      await _tryRegisterToken();
    } catch (err) {
      debugPrint('PushManager: getToken failed: $err');
    }

    _ready = true;
  }

  Future<void> showLocalNotification({
    required String title,
    required String body,
  }) =>
      _showLocal(title: title, body: body);

  void bindRegistrar(PushTokenRegistrar registrar) {
    _registrar = registrar;
    _tryRegisterToken();
  }

  void unbindRegistrar() {
    _registrar = null;
  }

  Future<void> _tryRegisterToken() async {
    final registrar = _registrar;
    final token = _lastToken;
    if (kIsWeb || registrar == null || token == null || token.isEmpty) return;
    try {
      await registrar(token: token, platform: _platformName());
    } catch (err) {
      debugPrint('PushManager: token register failed: $err');
    }
  }

  Future<void> updateAppBadge(int count) async {
    if (kIsWeb) return;
    try {
      if (count <= 0) {
        await _badgeChannel.invokeMethod('clearBadge');
      } else {
        await _badgeChannel.invokeMethod('setBadge', {'count': count});
      }
    } catch (err) {
      debugPrint('PushManager: badge update failed: $err');
    }
  }

  Future<void> _handleForegroundMessage(RemoteMessage message) async {
    final title = message.notification?.title ?? (message.data['title']?.toString() ?? 'اعلان جدید');
    final body = message.notification?.body ?? (message.data['body']?.toString() ?? '');
    await _showLocal(title: title, body: body);
  }

  Future<void> _showLocal({required String title, required String body}) async {
    try {
      const androidDetails = AndroidNotificationDetails(
        _channelId,
        _channelName,
        importance: Importance.max,
        priority: Priority.high,
        playSound: true,
        enableVibration: true,
      );
      const iosDetails = DarwinNotificationDetails(
        presentSound: true,
        presentAlert: true,
        presentBadge: true,
      );
      const details = NotificationDetails(android: androidDetails, iOS: iosDetails);
      await _localNotifications.show(DateTime.now().millisecondsSinceEpoch ~/ 1000, title, body, details);
    } catch (err) {
      debugPrint('PushManager: local notify failed: $err');
    }
  }

  String _platformName() {
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return 'android';
      case TargetPlatform.iOS:
        return 'ios';
      case TargetPlatform.macOS:
        return 'macos';
      case TargetPlatform.windows:
        return 'windows';
      case TargetPlatform.linux:
        return 'linux';
      case TargetPlatform.fuchsia:
        return 'fuchsia';
    }
  }
}
