# راهنمای استقرار داروچک

## اجزا

| جزء | محل | مقصد |
|---|---|---|
| Flutter | `lib/` و پلتفرم‌ها | موبایل/وب؛ build جداگانه |
| API | `server/` | Node runtime (Liara یا سرویس سازگار) |
| داده | `database/schema.sql` و `database/migrations/` | Supabase/Postgres |
| landing/B2B | `netlify-site/` | Netlify |

## متغیرهای Backend

ضروری:

```text
DATABASE_URL
JWT_SECRET
ADMIN_USERNAME
ADMIN_PASSWORD
```

اختیاری:

```text
JWT_EXPIRES_IN
REFRESH_EXPIRES_DAYS
FARAZSMS_API_KEY
FARAZSMS_PATTERN_CODE
FARAZSMS_SENDER_NUMBER
FARAZSMS_API_URL
FARAZSMS_CODE_PARAM
FARAZSMS_PURPOSE_PARAM
FCM_SERVER_KEY
UPLOAD_DIR
PORT
HOST
```

مقادیر واقعی نباید commit شوند. از `.env.example` به عنوان قرارداد استفاده کنید.

## Database

- `database/schema.sql` baseline قدیمی است.
- migrationهای افزایشی در `database/migrations/` برای Supabase SQL Editor یا `apply_migration` اجرا می‌شوند.
- migration عضویت/همکار/تبلیغ destructive نیست.

## Netlify

`netlify.toml` به `netlify-site/` اشاره می‌کند. این سایت landing/B2B است و API موبایل را جایگزین نمی‌کند؛ API با `API_BASE_URL` به backend متصل می‌شود. متغیرهای حساس در Netlify Environment Variables تنظیم شوند.

## Mobile UI / demo session

صفحه خانه موبایل در `lib/main.dart` با تجربه RTL جدید شامل دسته‌های پوست‌ومو، دندان‌پزشکی، مراکز زیبایی، آزمایشگاه، درمانگاه و بخش پذیرش مراکز درمانی پیاده‌سازی شده است. `DaroHomePage` و جریان ثبت درخواست همان instance احراز‌شده `ApiClient` را دریافت می‌کنند؛ متدهای `_authorizedGet` و `_authorizedPost` هدر Bearer را اضافه و در صورت انقضا refresh token را خودکار استفاده می‌کنند. توکن در متن UI، assetها یا repository چاپ نمی‌شود.

برای اجرای دمو با session واقعی، ابتدا از جریان login/OTP وارد شوید و سپس صفحه‌های خانه، درخواست دارو، سفارش‌ها، پروفایل و همکاری از همان session استفاده می‌کنند. برای اجرای محلی API:

```bash
flutter run --dart-define=API_URL=http://10.0.2.2:4000
```
