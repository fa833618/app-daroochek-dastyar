# هویت بصری داروچک

## ایده برند

داروچک باید هم‌زمان حس **اعتماد پزشکی** و **شبکه عملیاتی مدرن** را منتقل کند. نشان برند از یک فرم سبزِ نرم و چهارشاخه ساخته شده که در مرکز آن یک قطره/هسته شبکه‌ای قرار دارد؛ خط طلایی، مسیر روشن و premium بودن را یادآوری می‌کند.

## پالت

| نقش | مقدار |
|---|---|
| Midnight Ink | `#071B1B` |
| Deep Teal | `#0C2E2B` |
| Emerald | `#35D399` |
| Mint | `#B9FFD7` |
| Champagne Gold | `#F4C76B` |
| Muted Sage | `#9BB6AE` |

## رفتار ورود

صفحه قبل از نمایش محتوای اصلی، حدود ۱.۶۵ ثانیه یک splash آرام نشان می‌دهد: پس‌زمینه شبکه پزشکی، نشان داروچک، نام فارسی، شعار «داروی کمیاب، مسیر روشن.»، نوار پیشرفت و وضعیت «در حال اتصال به شبکه همکاران». سپس با fade کوتاه، hero و کارت‌های محصول وارد می‌شوند. برای کاربرانی که `prefers-reduced-motion` دارند، زمان و انیمیشن به حداقل می‌رسد.

## prompt لوگو

```text
Create a premium minimal brand symbol for a Persian healthcare platform named DaroCheck. Icon only, no letters and no words: an abstract emerald-green pharmacy cross fused with a refined droplet and a subtle connected-network node motif, geometric but warm, highly recognizable at 24px, balanced negative space, crisp vector-like edges, elegant luxury B2B identity, emerald green with a tiny champagne-gold accent, centered, isolated, native transparent background, no shadow, no mockup, no extra objects.
```

## prompt splash

```text
Create a cinematic premium startup splash background for a Persian healthcare and pharmacy network brand. Deep midnight teal background, luminous emerald glass orbits, subtle gold particles, a calm abstract medical network and a single soft glowing pharmacy cross in the distant center, sophisticated editorial luxury, high contrast but spacious dark safe area for white Persian headline overlay, no text, no letters, no logo, no people, no medical gore, polished website hero background, 16:9.
```

## فایل‌های استفاده‌شده

- `netlify-site/assets/darochek-mark-web.png`: لوگوی بهینه‌شده برای وب
- `netlify-site/assets/darochek-splash-web.jpg`: پس‌زمینه بهینه‌شده برای وب
- `netlify-site/index.html`: splash و استفاده از لوگو
- `netlify-site/styles.css`: motion system و hero atmosphere
